package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Database.DBConnection;
import org.apache.commons.lang3.StringEscapeUtils;

public class AssignReviewServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Set<String> VALID_REVIEW_TYPES = new HashSet<>(Arrays.asList("Probation", "Quarterly", "Yearly"));
    private static final Set<String> VALID_FORM_TYPES = new HashSet<>(Arrays.asList("KRA", "Feedback"));
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @SuppressWarnings("resource")
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set security headers
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("X-Frame-Options", "DENY");
        response.setHeader("X-XSS-Protection", "1; mode=block");
        response.setHeader("Content-Security-Policy", "default-src 'self'");

        // Session validation
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("Login.jsp");
            return;
        }

        // CSRF protection
        String csrfToken = request.getParameter("csrfToken");
        String sessionCsrfToken = (String) session.getAttribute("csrfToken");
        if (csrfToken == null || !csrfToken.equals(sessionCsrfToken)) {
            response.sendRedirect("AssignReview.jsp?error=Invalid request");
            return;
        }

        // Input validation and sanitization
        try {
            int managerId = (int) session.getAttribute("userId");
            int revieweeId = Integer.parseInt(request.getParameter("reviewee"));
            String reviewType = StringEscapeUtils.escapeHtml4(request.getParameter("reviewType"));
            String formType = StringEscapeUtils.escapeHtml4(request.getParameter("formType"));
            String assignedDate = request.getParameter("assignedDate");
            String deadline = request.getParameter("deadline");
            String[] selectedReviewers = request.getParameterValues("selectedReviewers");

            // Validate review type and form type
            if (!VALID_REVIEW_TYPES.contains(reviewType) || !VALID_FORM_TYPES.contains(formType)) {
                response.sendRedirect("AssignReview.jsp?error=Invalid review or form type");
                return;
            }

            // Validate dates
            LocalDate assignedDateObj = LocalDate.parse(assignedDate, DATE_FORMATTER);
            LocalDate deadlineObj = LocalDate.parse(deadline, DATE_FORMATTER);
            LocalDate currentDate = LocalDate.now();
            LocalDate maxDeadline = currentDate.plusDays(7);

            if (assignedDateObj.isBefore(currentDate) || deadlineObj.isBefore(currentDate) || deadlineObj.isAfter(maxDeadline)) {
                response.sendRedirect("AssignReview.jsp?error=Invalid date range");
                return;
            }

            // Validate number of reviewers
            if (selectedReviewers == null || selectedReviewers.length == 0 || selectedReviewers.length > 3) {
                response.sendRedirect("AssignReview.jsp?error=Invalid number of reviewers");
                return;
            }

            // Validate reviewee exists and belongs to the manager
            if (!validateReviewee(managerId, revieweeId)) {
                response.sendRedirect("AssignReview.jsp?error=Invalid reviewee");
                return;
            }

            // Validate all reviewers exist and belong to the manager
            if (!validateReviewers(managerId, selectedReviewers)) {
                response.sendRedirect("AssignReview.jsp?error=Invalid reviewer selection");
                return;
            }

            Connection connection = null;
            PreparedStatement preparedStatement = null;

            try {
                connection = DBConnection.getConnection();
                connection.setAutoCommit(false); // Start transaction

                // Insert review record
                String reviewQuery = "INSERT INTO Reviews (employee_id, review_type, form_type, assigned_date, deadline, status) VALUES (?, ?, ?, ?, ?, 'Pending')";
                preparedStatement = connection.prepareStatement(reviewQuery, PreparedStatement.RETURN_GENERATED_KEYS);
                preparedStatement.setInt(1, revieweeId);
                preparedStatement.setString(2, reviewType);
                preparedStatement.setString(3, formType);
                preparedStatement.setString(4, assignedDate);
                preparedStatement.setString(5, deadline);
                preparedStatement.executeUpdate();

                // Get the generated review ID
                int reviewId = 0;
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        reviewId = generatedKeys.getInt(1);
                    }
                }

                // Insert review assignments
                String assignmentQuery = "INSERT INTO Review_Assignments (review_id, assigned_by, assigned_to, status) VALUES (?, ?, ?, 'Pending')";
                preparedStatement = connection.prepareStatement(assignmentQuery);
                for (String reviewerId : selectedReviewers) {
                    preparedStatement.setInt(1, reviewId);
                    preparedStatement.setInt(2, managerId);
                    preparedStatement.setInt(3, Integer.parseInt(reviewerId));
                    preparedStatement.addBatch();
                }
                preparedStatement.executeBatch();

                // Commit transaction
                connection.commit();

                // Set success message and redirect to Assigned Reviews page
                session.setAttribute("message", "Review assigned successfully.");
                response.sendRedirect("forward?page=AssignedReviews");
            } catch (SQLException e) {
                // Rollback transaction on error
                if (connection != null) {
                    try {
                        connection.rollback();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
                e.printStackTrace();
                response.sendRedirect("AssignReview.jsp?error=Error assigning review. Please try again.");
            } finally {
                try {
                    if (preparedStatement != null) preparedStatement.close();
                    if (connection != null) connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (NumberFormatException | DateTimeParseException e) {
            response.sendRedirect("AssignReview.jsp?error=Invalid input format");
        }
    }

    private boolean validateReviewee(int managerId, int revieweeId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Users WHERE id = ? AND manager_assigned = ? AND status = 'Active'";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, revieweeId);
            preparedStatement.setInt(2, managerId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1) > 0;
                }
                return false;
            }
        }
    }

    private boolean validateReviewers(int managerId, String[] reviewerIds) throws SQLException {
        String query = "SELECT COUNT(*) FROM Users WHERE id = ? AND manager_assigned = ? AND status = 'Active'";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            for (String reviewerId : reviewerIds) {
                preparedStatement.setInt(1, Integer.parseInt(reviewerId));
                preparedStatement.setInt(2, managerId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (!resultSet.next() || resultSet.getInt(1) == 0) {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}