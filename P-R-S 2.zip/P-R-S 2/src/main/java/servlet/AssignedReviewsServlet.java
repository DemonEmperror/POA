package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Database.DBConnection;

public class AssignedReviewsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userName") == null || session.getAttribute("userRole") == null) {
            response.sendRedirect("Login.jsp");
            return;
        }
        String userName = (String) session.getAttribute("userName");
        String role = (String) session.getAttribute("userRole");

        if (!role.equals("Manager")) {
            response.sendRedirect("Login.jsp");
            return;
        }

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnection.getConnection();
            String query = "SELECT ra.id AS review_id, " +
                           "u1.name AS reviewee, " +
                           "u2.name AS reviewer, " +
                           "ra.status, " +
                           "r.deadline " +
                           "FROM Review_Assignments ra " +
                           "JOIN Reviews r ON ra.review_id = r.id " +
                           "JOIN Users u1 ON r.employee_id = u1.id " +
                           "JOIN Users u2 ON ra.assigned_to = u2.id " +
                           "WHERE ra.assigned_by = (SELECT id FROM Users WHERE name = ? LIMIT 1) " +
                           "AND ra.status IN ('Pending', 'In Progress', 'Completed', 'Revoked', 'Reopened') " +
                           "ORDER BY r.deadline ASC";

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, userName);
            resultSet = preparedStatement.executeQuery();

            List<Map<String, Object>> reviewAssignments = new ArrayList<>();
            while (resultSet.next()) {
                Map<String, Object> reviewAssignment = new HashMap<>();
                reviewAssignment.put("review_id", resultSet.getInt("review_id"));
                reviewAssignment.put("reviewee", resultSet.getString("reviewee"));
                reviewAssignment.put("reviewer", resultSet.getString("reviewer"));
                reviewAssignment.put("status", resultSet.getString("status"));
                reviewAssignment.put("deadline", resultSet.getDate("deadline"));
                reviewAssignments.add(reviewAssignment);
            }

            request.setAttribute("reviewAssignments", reviewAssignments);
            request.getRequestDispatcher("WEB-INF/jsp/AssignedReviews.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error fetching data: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}