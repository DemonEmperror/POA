package servlet;

import Database.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class DataEntryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String formType = request.getParameter("form_type");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String message = "";

        try {
            connection = DBConnection.getConnection();

            if ("User".equalsIgnoreCase(formType)) {
                String name = request.getParameter("name");
                String empid = request.getParameter("empid");
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                String role = request.getParameter("role");
                String status = request.getParameter("status");
                String managerAssigned = request.getParameter("manager_assigned");

                String query = "INSERT INTO Users (employee_id, name, email, password, role, status, manager_assigned) VALUES (?, ?, ?, ?, ?, ?, ?)";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, empid);
                preparedStatement.setString(2, name);
                preparedStatement.setString(3, email);
                preparedStatement.setString(4, password);
                preparedStatement.setString(5, role);
                preparedStatement.setString(6, status);
                if (managerAssigned != null && !managerAssigned.isEmpty()) {
                    preparedStatement.setInt(7, Integer.parseInt(managerAssigned));
                } else {
                    preparedStatement.setNull(7, java.sql.Types.INTEGER);
                }
                preparedStatement.executeUpdate();
                message = "User added successfully";
            } else if ("Category".equalsIgnoreCase(formType)) {
                String categoryName = request.getParameter("categoryName");

                String query = "INSERT INTO Categories (name) VALUES (?)";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, categoryName);
                preparedStatement.executeUpdate();
                message = "Category added successfully";
            } else if ("KRA".equalsIgnoreCase(formType)) {
                int categoryId = Integer.parseInt(request.getParameter("categoryId"));
                String kraQuestion = request.getParameter("kra_question");

                String query = "INSERT INTO Questions (category_id, question) VALUES (?, ?)";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, categoryId);
                preparedStatement.setString(2, kraQuestion);
                preparedStatement.executeUpdate();
                message = "Question added successfully";
            } else if ("Weights".equalsIgnoreCase(formType)) {
                Map<String, String[]> parameterMap = request.getParameterMap();
                String updateQuery = "UPDATE Categories SET weight = ? WHERE id = ?";

                preparedStatement = connection.prepareStatement(updateQuery);

                for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
                    if (entry.getKey().startsWith("weights[")) {
                        int categoryId = Integer.parseInt(entry.getKey().replace("weights[", "").replace("]", ""));
                        double weight = Double.parseDouble(entry.getValue()[0]);

                        preparedStatement.setDouble(1, weight);
                        preparedStatement.setInt(2, categoryId);
                        preparedStatement.addBatch();
                    }
                }
                preparedStatement.executeBatch();
                message = "Weights updated successfully.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            message = "An error occurred";
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        request.setAttribute("message", message);
        request.getRequestDispatcher("WEB-INF/jsp/DataEntryDashboard.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnection.getConnection();
            String query = "SELECT id, name, weight FROM Categories";
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            Map<Integer, Double> weights = new LinkedHashMap<>();
            while (resultSet.next()) {
                weights.put(resultSet.getInt("id"), resultSet.getDouble("weight"));
            }
            request.setAttribute("weights", weights);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        request.getRequestDispatcher("WEB-INF/jsp/DataEntryDashboard.jsp").forward(request, response);
    }
}