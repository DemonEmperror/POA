package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONObject;

public class FetchReviewersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        HttpSession sessionObj = request.getSession(false);
        if (sessionObj == null || sessionObj.getAttribute("userName") == null || sessionObj.getAttribute("userRole") == null) {
            response.sendRedirect("Login.jsp");
            return;
        }

        String userName = (String) sessionObj.getAttribute("userName");
        String role = (String) sessionObj.getAttribute("userRole");

        if (!"Manager".equals(role)) {
            response.sendRedirect("Login.jsp");
            return;
        }

        String revieweeId = request.getParameter("revieweeId");
        JSONArray reviewersArray = new JSONArray();

        if (revieweeId != null && !revieweeId.isEmpty()) {
            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            try {
                connection = Database.DBConnection.getConnection();

                // Get reviewers under the same manager, excluding the reviewee
                String query = "SELECT id, name FROM Users WHERE manager_assigned = (SELECT id FROM Users WHERE email = ?) AND status = 'Active' AND id != ?";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, userName);
                preparedStatement.setInt(2, Integer.parseInt(revieweeId));
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    JSONObject reviewer = new JSONObject();
                    reviewer.put("id", resultSet.getInt("id"));
                    reviewer.put("name", resultSet.getString("name"));
                    reviewersArray.put(reviewer);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (resultSet != null) resultSet.close();
                    if (preparedStatement != null) preparedStatement.close();
                    if (connection != null) connection.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        PrintWriter out = response.getWriter();
        out.print(reviewersArray.toString());
        out.flush();
    }
}
