package servlet;

import Database.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class KRAFormAutoSaveServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String reviewIdStr = request.getParameter("reviewId");
        String questionIdStr = request.getParameter("questionId");
        String reviewerIdStr = request.getParameter("reviewerId");
        String responseStr = request.getParameter("response");
        String comment = request.getParameter("comment");

        if (reviewIdStr == null || questionIdStr == null || reviewerIdStr == null || responseStr == null || reviewIdStr.isEmpty() || questionIdStr.isEmpty() || reviewerIdStr.isEmpty() || responseStr.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input");
            return;
        }

        try {
            int reviewId = Integer.parseInt(reviewIdStr);
            int questionId = Integer.parseInt(questionIdStr);
            int reviewerId = Integer.parseInt(reviewerIdStr);
            int responseValue = Integer.parseInt(responseStr);

            Connection connection = null;
            PreparedStatement preparedStatement = null;

            try {
                connection = DBConnection.getConnection();
                String query = "INSERT INTO KRA_Form (review_id, question_id, reviewer_id, response, comment) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE response = VALUES(response), comment = VALUES(comment)";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, reviewId);
                preparedStatement.setInt(2, questionId);
                preparedStatement.setInt(3, reviewerId);
                preparedStatement.setInt(4, responseValue);
                preparedStatement.setString(5, comment);
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
            } finally {
                try {
                    if (preparedStatement != null) preparedStatement.close();
                    if (connection != null) connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid number format");
        }
    }
}