package servlet;

import Database.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;

public class KRAFormSubmitServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int reviewId = Integer.parseInt(request.getParameter("reviewId"));
        int reviewerId = (int) request.getSession().getAttribute("userId");

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DBConnection.getConnection();

            Enumeration<String> parameterNames = request.getParameterNames();
            while (parameterNames.hasMoreElements()) {
                String paramName = parameterNames.nextElement();
                if (paramName.startsWith("question_")) {
                    int questionId = Integer.parseInt(paramName.split("_")[1]);
                    int responseValue = Integer.parseInt(request.getParameter(paramName));
                    String comment = request.getParameter("comment_" + questionId);

                    String query = "INSERT INTO KRA_Form (review_id, question_id, reviewer_id, response, comment) VALUES (?, ?, ?, ?, ?) " +
                                   "ON DUPLICATE KEY UPDATE response = VALUES(response), comment = VALUES(comment)";
                    preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setInt(1, reviewId);
                    preparedStatement.setInt(2, questionId);
                    preparedStatement.setInt(3, reviewerId);
                    preparedStatement.setInt(4, responseValue);
                    preparedStatement.setString(5, comment);
                    preparedStatement.executeUpdate();
                }
            }

            // Mark this review as completed for the current reviewer
            String updateQuery = "UPDATE Review_Assignments SET status = 'Completed' WHERE review_id = ? AND assigned_to = ?";
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setInt(1, reviewId);
            preparedStatement.setInt(2, reviewerId);
            preparedStatement.executeUpdate();
            preparedStatement.close();

            // Check if all reviewers have completed the review
            String checkQuery = "SELECT COUNT(*) AS pending_count FROM Review_Assignments WHERE review_id = ? AND status != 'Completed'";
            preparedStatement = connection.prepareStatement(checkQuery);
            preparedStatement.setInt(1, reviewId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next() && resultSet.getInt("pending_count") == 0) {
                // All reviewers have completed the review, update the review status to 'Completed'
                String updateReviewQuery = "UPDATE Reviews SET status = 'Completed' WHERE id = ?";
                preparedStatement = connection.prepareStatement(updateReviewQuery);
                preparedStatement.setInt(1, reviewId);
                preparedStatement.executeUpdate();
            }
            resultSet.close();
            preparedStatement.close();

            response.setStatus(HttpServletResponse.SC_OK);
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}