package servlet;

import Database.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            Connection connection = DBConnection.getConnection();
            String query = "SELECT * FROM Users WHERE email = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("userId", resultSet.getInt("id"));
                session.setAttribute("userName", resultSet.getString("name"));
                session.setAttribute("userRole", resultSet.getString("role"));

                String role = resultSet.getString("role");
                switch (role) {
                    case "Manager":
                        response.sendRedirect("forward?page=ManagerDashboard");
                        break;
                    case "TeamLead":
                    case "SSE":
                    case "JSE":
                    case "Intern":
                        response.sendRedirect("forward?page=ReviewerDashboard");
                        break;
                    case "DataEntry":
                        response.sendRedirect("forward?page=DataEntryDashboard");
                        break;
                    default:
                        response.sendRedirect("forward?page=login&error=Invalid role");
                        break;
                }
            } else {
                response.sendRedirect("forward?page=login&error=Invalid email or password");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("forward?page=error/500");
        }
    }
}