package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Database.DBConnection;
import java.util.ArrayList;
import java.util.List;

public class ReopenReviewServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int reviewId;
        try {
            reviewId = Integer.parseInt(request.getParameter("reviewId"));
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid review ID format");
            return;
        }

        String managerComment = request.getParameter("managerComment");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        PreparedStatement deleteAssignmentsStmt = null;
        PreparedStatement insertNewAssignmentsStmt = null;
        PreparedStatement selectReviewersStmt = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnection.getConnection();
            connection.setAutoCommit(false); // Start transaction

            // Update review status and manager comment
            String updateReviewQuery = "UPDATE Reviews SET manager_comment = ?, status = 'Reopened' WHERE id = ?";
            preparedStatement = connection.prepareStatement(updateReviewQuery);
            preparedStatement.setString(1, managerComment);
            preparedStatement.setInt(2, reviewId);
            preparedStatement.executeUpdate();

            // Fetch original reviewers
            String selectReviewersQuery = "SELECT assigned_to FROM Review_Assignments WHERE review_id = ?";
            selectReviewersStmt = connection.prepareStatement(selectReviewersQuery);
            selectReviewersStmt.setInt(1, reviewId);
            resultSet = selectReviewersStmt.executeQuery();

            List<Integer> reviewerIds = new ArrayList<>();
            while (resultSet.next()) {
                reviewerIds.add(resultSet.getInt("assigned_to"));
            }

            // Delete old review assignments
            String deleteAssignmentsQuery = "DELETE FROM Review_Assignments WHERE review_id = ?";
            deleteAssignmentsStmt = connection.prepareStatement(deleteAssignmentsQuery);
            deleteAssignmentsStmt.setInt(1, reviewId);
            deleteAssignmentsStmt.executeUpdate();

            // Reassign the review to the same reviewers as fresh reviews
            String insertNewAssignmentsQuery = "INSERT INTO Review_Assignments (review_id, assigned_to, assigned_by, assigned_at, status) VALUES (?, ?, ?, NOW(), 'Reopened')";
            insertNewAssignmentsStmt = connection.prepareStatement(insertNewAssignmentsQuery);

            int managerId = 1; // Assuming 1 is the manager's ID, replace with actual manager ID
            for (int reviewerId : reviewerIds) {
                insertNewAssignmentsStmt.setInt(1, reviewId);
                insertNewAssignmentsStmt.setInt(2, reviewerId);
                insertNewAssignmentsStmt.setInt(3, managerId);
                insertNewAssignmentsStmt.addBatch();
            }

            insertNewAssignmentsStmt.executeBatch();

            connection.commit(); // Commit transaction

            // Redirect to assigned reviews page with a placeholder message
            response.sendRedirect(request.getContextPath() + "/forward?page=AssignedReviews&message=Review%20reopened%20successfully");

        } catch (Exception e) {
            e.printStackTrace();
            if (connection != null) {
                try {
                    connection.rollback(); // Rollback transaction in case of error
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error: " + e.getMessage());
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (selectReviewersStmt != null) selectReviewersStmt.close();
                if (insertNewAssignmentsStmt != null) insertNewAssignmentsStmt.close();
                if (deleteAssignmentsStmt != null) deleteAssignmentsStmt.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}