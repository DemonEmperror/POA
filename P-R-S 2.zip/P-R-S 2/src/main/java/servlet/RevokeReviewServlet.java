package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Database.DBConnection;

public class RevokeReviewServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get review_assignment_id from request
        String reviewAssignmentIdParam = request.getParameter("review_assignment_id");
        System.out.println("Review Assignment ID Parameter: " + reviewAssignmentIdParam);

        if (reviewAssignmentIdParam == null || reviewAssignmentIdParam.isEmpty()) {
            System.out.println("Review Assignment ID is null or empty");
            request.setAttribute("errorMessage", "Invalid review assignment ID.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        int reviewAssignmentId;
        try {
            reviewAssignmentId = Integer.parseInt(reviewAssignmentIdParam);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Review Assignment ID format: " + reviewAssignmentIdParam);
            request.setAttribute("errorMessage", "Invalid review assignment ID format.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Get database connection
            connection = DBConnection.getConnection();
            System.out.println("Database connection: " + (connection != null ? "Successful" : "Failed"));

            // Prepare query to update status
            String query = "UPDATE Review_Assignments SET status = 'Revoked' WHERE id = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, reviewAssignmentId);

            // Execute update and get affected rows
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println("Rows Affected: " + rowsAffected);

            // Check if any row was updated
            if (rowsAffected > 0) {
                HttpSession session = request.getSession();
                session.setAttribute("message", "Review revoked successfully.");
            } else {
                System.out.println("No review found with the given ID: " + reviewAssignmentId);
                request.setAttribute("errorMessage", "No review found with the given ID.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error revoking review: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Redirect to the Assigned Reviews page
        response.sendRedirect(request.getContextPath() + "/AssignedReviewsServlet");
    }
}