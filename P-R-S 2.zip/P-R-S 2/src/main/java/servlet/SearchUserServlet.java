package servlet;

import Database.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SearchUserServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String query = request.getParameter("query");
        String managerName = (String) request.getSession().getAttribute("userName");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            connection = DBConnection.getConnection();
            String sql = "SELECT id, name, employee_id FROM Users WHERE manager_assigned = (SELECT id FROM Users WHERE name = ?) AND (name LIKE ? OR employee_id LIKE ?) AND status = 'Active'";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, managerName);
            preparedStatement.setString(2, "%" + query + "%");
            preparedStatement.setString(3, "%" + query + "%");
            resultSet = preparedStatement.executeQuery();

            List<String> users = new ArrayList<>();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String employeeId = resultSet.getString("employee_id");
                users.add(String.format("{\"id\":%d,\"name\":\"%s\",\"employee_id\":\"%s\"}", id, name, employeeId));
            }
            out.print("[" + String.join(",", users) + "]");
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        } finally {
            if (resultSet != null) try { resultSet.close(); } catch (SQLException e) { e.printStackTrace(); }
            if (preparedStatement != null) try { preparedStatement.close(); } catch (SQLException e) { e.printStackTrace(); }
            if (connection != null) try { connection.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}