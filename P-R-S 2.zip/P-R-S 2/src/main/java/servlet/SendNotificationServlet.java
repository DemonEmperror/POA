package servlet;

import Database.DBConnection;
import utility.EmailUtility;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SendNotificationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int reviewId = Integer.parseInt(request.getParameter("review_id"));
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnection.getConnection();
            String query = "SELECT u.email, u.employee_id, u.name, r.created_at, r.deadline " +
                           "FROM Users u " +
                           "INNER JOIN Reviews r ON u.employee_id = r.employee_id " +
                           "WHERE r.id = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, reviewId);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String email = resultSet.getString("email");
                int employeeId = resultSet.getInt("employee_id");
                String name = resultSet.getString("name");
                String assignedDate = resultSet.getTimestamp("created_at").toString();
                String deadline = resultSet.getDate("deadline").toString();
                String reviewLink = "http://yourdomain.com/review?review_id=" + reviewId;

                String subject = "Reminder: Pending Review";
                String message = String.format("Dear %s,\n\nYou have a pending review.\n\nEmployee ID: %d\nName: %s\nAssigned Date: %s\nDeadline: %s\n\nPlease complete the review by clicking the link below:\n%s\n\nRegards,\nTeam",
                                                 name, employeeId, name, assignedDate, deadline, reviewLink);

                EmailUtility.sendEmail(email, subject, message);

                response.sendRedirect("forward?page=Notifications&success=true");
            } else {
                response.sendRedirect("forward?page=Notifications&error=Review%20not%20found");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("forward?page=Notifications&error=Server%20error");
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}