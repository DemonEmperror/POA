package servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class UserProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/jsp/UserProfile.jsp").forward(request, response);
    }

    @SuppressWarnings("resource")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userName") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        String userName = (String) session.getAttribute("userName");
        String currentPassword = request.getParameter("currentPassword");
        String newPassword = request.getParameter("newPassword");
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = Database.DBConnection.getConnection();

            // Verify current password
            String verifyPasswordQuery = "SELECT password FROM Users WHERE name = ?";
            preparedStatement = connection.prepareStatement(verifyPasswordQuery);
            preparedStatement.setString(1, userName);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next() && resultSet.getString("password").equals(currentPassword)) {
                // Update name and email
                if (name != null && email != null) {
                    String updateQuery = "UPDATE Users SET name = ?, email = ? WHERE name = ?";
                    preparedStatement = connection.prepareStatement(updateQuery);
                    preparedStatement.setString(1, name);
                    preparedStatement.setString(2, email);
                    preparedStatement.setString(3, userName);
                    preparedStatement.executeUpdate();

                    session.setAttribute("userName", name); // Update session attribute if name is changed
                }

                // Change password
                if (newPassword != null) {
                    String changePasswordQuery = "UPDATE Users SET password = ? WHERE name = ?";
                    preparedStatement = connection.prepareStatement(changePasswordQuery);
                    preparedStatement.setString(1, newPassword);
                    preparedStatement.setString(2, userName);
                    preparedStatement.executeUpdate();
                }

                response.sendRedirect("forward?page=UserProfile");
            } else {
                response.sendRedirect("error.jsp?message=Invalid%20password");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}