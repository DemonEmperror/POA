package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Database.DBConnection;

public class ViewReviewServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("resource")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userName") == null || session.getAttribute("userRole") == null) {
            response.sendRedirect("Login.jsp");
            return;
        }
        @SuppressWarnings("unused")
		String userName = (String) session.getAttribute("userName");
        String role = (String) session.getAttribute("userRole");

        if (!role.equals("Manager")) {
            response.sendRedirect("Login.jsp");
            return;
        }

        String reviewIdStr = request.getParameter("review_id");
        if (reviewIdStr == null || reviewIdStr.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Review ID is required");
            return;
        }
        
        int reviewId;
        try {
            reviewId = Integer.parseInt(reviewIdStr);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid review ID format");
            return;
        }

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnection.getConnection();
            String query = "SELECT u2.name AS reviewee, " +
                           "GROUP_CONCAT(DISTINCT u1.name SEPARATOR ', ') AS reviewers, " +
                           "u3.name AS manager, " +
                           "r.form_type, " +
                           "r.review_type, " +
                           "ra.assigned_at, " +
                           "ra.completed_at, " +
                           "r.final_weighted_score, " +
                           "r.manager_comment, " +
                           "r.status " +
                           "FROM Review_Assignments ra " +
                           "JOIN Reviews r ON ra.review_id = r.id " +
                           "JOIN Users u1 ON ra.assigned_to = u1.id " +
                           "JOIN Users u2 ON r.employee_id = u2.id " +
                           "JOIN Users u3 ON ra.assigned_by = u3.id " +
                           "WHERE r.id = ? " +
                           "GROUP BY u2.name, u3.name, r.form_type, r.review_type, ra.assigned_at, ra.completed_at, r.final_weighted_score, r.manager_comment, r.status";

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, reviewId);
            resultSet = preparedStatement.executeQuery();

            Map<String, Object> reviewDetails = new HashMap<>();
            if (resultSet.next()) {
                reviewDetails.put("reviewee", resultSet.getString("reviewee"));
                reviewDetails.put("reviewers", resultSet.getString("reviewers"));
                reviewDetails.put("manager", resultSet.getString("manager"));
                reviewDetails.put("formType", resultSet.getString("form_type"));
                reviewDetails.put("reviewType", resultSet.getString("review_type"));
                reviewDetails.put("assignedDate", resultSet.getTimestamp("assigned_at"));
                reviewDetails.put("completionDate", resultSet.getTimestamp("completed_at"));
                reviewDetails.put("reviewId", reviewId);
                reviewDetails.put("finalWeightedScore", resultSet.getDouble("final_weighted_score"));
                reviewDetails.put("managerComment", resultSet.getString("manager_comment") != null ? resultSet.getString("manager_comment") : "");
                reviewDetails.put("status", resultSet.getString("status"));
            }

            query = "SELECT category_name, question, kra_response, kra_comment, weight FROM (" +
                    "SELECT c.name AS category_name, q.question, " +
                    "GROUP_CONCAT(DISTINCT CONCAT(u.name, '-', kf.response) ORDER BY kf.reviewer_id SEPARATOR ', ') AS kra_response, " +
                    "GROUP_CONCAT(DISTINCT kf.comment ORDER BY kf.reviewer_id SEPARATOR ' | ') AS kra_comment, " +
                    "kf.weight " +
                    "FROM KRA_Form kf " +
                    "JOIN Questions q ON kf.question_id = q.id " +
                    "JOIN Categories c ON q.category_id = c.id " +
                    "JOIN Users u ON kf.reviewer_id = u.id " +
                    "WHERE kf.review_id = ? " +
                    "GROUP BY c.name, q.question, kf.weight) AS subquery " +
                    "ORDER BY category_name";

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, reviewId);
            resultSet = preparedStatement.executeQuery();

            Map<String, List<Map<String, String>>> categories = new LinkedHashMap<>();
            double totalWeightedScore = 0.0;
            double totalWeight = 0.0;
            while (resultSet.next()) {
                String categoryName = resultSet.getString("category_name");
                String question = resultSet.getString("question");
                String kraResponse = resultSet.getString("kra_response");
                String kraComment = resultSet.getString("kra_comment");
                double weight = resultSet.getDouble("weight");
                Map<String, String> questionDetails = new HashMap<>();
                questionDetails.put("question", question);
                questionDetails.put("kraResponse", kraResponse);
                questionDetails.put("kraComment", kraComment);
                questionDetails.put("weight", Double.toString(weight));

                if (!categories.containsKey(categoryName)) {
                    categories.put(categoryName, new ArrayList<>());
                }
                categories.get(categoryName).add(questionDetails);

                // Calculate weighted score
                String[] responses = kraResponse.split(",");
                double questionScore = 0.0;
                for (String responseDetail : responses) {
                    String[] responseParts = responseDetail.split("-");
                    int score = Integer.parseInt(responseParts[1]);
                    questionScore += score;
                }
                questionScore /= responses.length; // Average score for the question
                totalWeightedScore += questionScore * weight;
                totalWeight += weight;
            }

            double finalWeightedScore = totalWeight > 0 ? totalWeightedScore / totalWeight : 0.0;
            reviewDetails.put("finalWeightedScore", finalWeightedScore);

            // Calculate the percentage and rating
            double scorePercentage = finalWeightedScore * 20; // since the rating is out of 5, multiply by 20 to get percentage
            reviewDetails.put("scorePercentage", scorePercentage);

            String rating;
            if (scorePercentage >= 90) {
                rating = "Outstanding – Eligible for promotion/bonus.";
            } else if (scorePercentage >= 75) {
                rating = "Exceeds Expectations – Consider for leadership roles.";
            } else if (scorePercentage >= 60) {
                rating = "Meets Expectations – Continue in current role.";
            } else if (scorePercentage >= 50) {
                rating = "Needs Improvement – Develop an improvement plan and provide training.";
            } else {
                rating = "Unsatisfactory – Immediate performance improvement required.";
            }
            reviewDetails.put("rating", rating);

            reviewDetails.put("categories", categories);

            request.setAttribute("reviewDetails", reviewDetails);
            request.getRequestDispatcher("/WEB-INF/jsp/ViewReview.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error fetching data: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}