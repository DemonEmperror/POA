# POA System (Plan of Action)

A Java web application for managing daily work plans, approvals, and tracking.

## Overview

The POA (Plan of Action) System is a comprehensive web application designed to streamline the process of creating, reviewing, and approving daily work plans. It supports multiple user roles including Manager, Team Lead, SDE, JSDE, and Intern, each with specific permissions and capabilities.

## Features

- **User Authentication**: Secure login system with role-based access control
- **Daily Plan Creation**: Employees can create and submit daily work plans
- **Approval Workflow**: Team Leads and Managers can review and approve plans
- **Plan Tracking**: Monitor plan status and history
- **Performance Metrics**: Track estimated vs. actual time spent on tasks
- **Responsive Design**: Works on desktop and mobile devices

## Technology Stack

- **Backend**: Java Servlets, JSP
- **Frontend**: HTML, CSS, JavaScript
- **Database**: MySQL
- **Server**: Apache Tomcat

## Setup Instructions

### Prerequisites

- JDK 8 or higher
- Apache Tomcat 8 or higher
- MySQL 5.7 or higher

### Database Setup

1. Create a MySQL database:
   ```
   mysql -u root -p < POA/database/init.sql
   ```

2. Update database connection settings in `DBUtil.java` if needed:
   ```java
   private static final String JDBC_URL = "jdbc:mysql://localhost:3306/poa_system";
   private static final String JDBC_USER = "root";
   private static final String JDBC_PASSWORD = "root"; // Change this to your actual MySQL password
   ```

### Project Setup

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/poa-system.git
   ```

2. Set up the project structure in your Java IDE (Eclipse, IntelliJ, etc.)

3. Add the required JAR files to the project:
   - JDBC MySQL Connector
   - Servlet API
   - JSTL

4. Build the project

### Deployment

1. Deploy the WAR file to your Tomcat server

2. Access the application at: http://localhost:8080/poa

## User Roles and Access

- **Admin**: Full system access, user management
- **Manager**: Approve plans (final approval), view reports
- **Team Lead**: Review and approve plans (initial approval), create own plans
- **SDE/JSDE/Intern**: Create and submit daily plans, update actual time spent

## Default Users

| Email | Password | Role |
|-------|----------|------|
| admin@example.com | admin123 | Admin |
| manager@example.com | manager123 | Manager |
| teamlead@example.com | teamlead123 | Team Lead |
| sde@example.com | sde123 | SDE |
| jsde@example.com | jsde123 | JSDE |
| intern@example.com | intern123 | Intern |

## Project Structure

```
POA/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── poa/
│       │           ├── controller/
│       │           │   ├── filter/
│       │           │   │   └── AuthenticationFilter.java
│       │           │   ├── ApprovalServlet.java
│       │           │   ├── LoginServlet.java
│       │           │   ├── LogoutServlet.java
│       │           │   └── PlanServlet.java
│       │           ├── dao/
│       │           │   ├── ApprovalDAO.java
│       │           │   ├── PlanDAO.java
│       │           │   ├── PlanDeliverableDAO.java
│       │           │   └── UserDAO.java
│       │           ├── model/
│       │           │   ├── Approval.java
│       │           │   ├── Plan.java
│       │           │   ├── PlanDeliverable.java
│       │           │   ├── User.java
│       │           │   └── WorkLog.java
│       │           ├── service/
│       │           └── util/
│       │               ├── DBUtil.java
│       │               └── PasswordUtil.java
│       └── webapp/
│           ├── WEB-INF/
│           │   ├── lib/
│           │   ├── classes/
│           │   └── web.xml
│           ├── css/
│           │   └── style.css
│           ├── js/
│           ├── images/
│           ├── jsp/
│           │   ├── admin/
│           │   │   └── dashboard.jsp
│           │   ├── manager/
│           │   │   ├── dashboard.jsp
│           │   │   ├── pending_approvals.jsp
│           │   │   └── review_plan.jsp
│           │   ├── teamlead/
│           │   │   ├── dashboard.jsp
│           │   │   ├── pending_approvals.jsp
│           │   │   └── review_plan.jsp
│           │   ├── employee/
│           │   │   ├── create_plan.jsp
│           │   │   ├── dashboard.jsp
│           │   │   ├── edit_plan.jsp
│           │   │   ├── plan_history.jsp
│           │   │   └── view_plan.jsp
│           │   ├── footer.jsp
│           │   └── header.jsp
│           ├── index.jsp
│           └── login.jsp
└── database/
    └── init.sql
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributors

- Your Name - Initial work