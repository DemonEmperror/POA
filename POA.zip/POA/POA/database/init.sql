-- Database Schema for POA System
CREATE DATABASE IF NOT EXISTS poa_system;
USE poa_system;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Manager', 'Team_Lead', 'SDE', 'JSDE', 'Intern', 'Admin') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Plans Table
CREATE TABLE IF NOT EXISTS plans (
    plan_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Needs_Rework') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Plan Deliverables Table
CREATE TABLE IF NOT EXISTS plan_deliverables (
    deliverable_id INT PRIMARY KEY AUTO_INCREMENT,
    plan_id INT NOT NULL,
    description TEXT NOT NULL,
    estimated_time DECIMAL(4,2) NOT NULL,
    actual_time DECIMAL(4,2),
    overflow_hours DECIMAL(4,2) DEFAULT 0,
    rework ENUM('Yes', 'No', 'None') DEFAULT 'None',
    achieved ENUM('Yes', 'No', 'None') DEFAULT 'None',
    FOREIGN KEY (plan_id) REFERENCES plans(plan_id)
);

-- End of Day Work Log
CREATE TABLE IF NOT EXISTS work_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    plan_id INT NOT NULL,
    actual_time DECIMAL(4,2),
    unplanned_work TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (plan_id) REFERENCES plans(plan_id)
);

-- Approval Workflow Table
CREATE TABLE IF NOT EXISTS approvals (
    approval_id INT PRIMARY KEY AUTO_INCREMENT,
    plan_id INT NOT NULL,
    approved_by INT NOT NULL,
    role ENUM('Team_Lead', 'Manager') NOT NULL,
    status ENUM('Approved', 'Rejected', 'Needs_Rework') NOT NULL,
    comments TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (plan_id) REFERENCES plans(plan_id),
    FOREIGN KEY (approved_by) REFERENCES users(user_id)
);

-- Indexing for Performance
CREATE INDEX idx_user_role ON users(role);
CREATE INDEX idx_plan_status ON plans(status);
CREATE INDEX idx_approval_status ON approvals(status);

-- Insert sample data
-- Admin user (password: admin123)
INSERT INTO users (name, email, password_hash, role)
VALUES ('Admin User', 'admin@example.com', 'admin123', 'Admin');

-- Manager (password: manager123)
INSERT INTO users (name, email, password_hash, role)
VALUES ('John Manager', 'manager@example.com', 'manager123', 'Manager');

-- Team Lead (password: teamlead123)
INSERT INTO users (name, email, password_hash, role)
VALUES ('Jane Team Lead', 'teamlead@example.com', 'teamlead123', 'Team_Lead');

-- SDE (password: sde123)
INSERT INTO users (name, email, password_hash, role)
VALUES ('Bob Developer', 'sde@example.com', 'sde123', 'SDE');

-- JSDE (password: jsde123)
INSERT INTO users (name, email, password_hash, role)
VALUES ('Alice Junior', 'jsde@example.com', 'jsde123', 'JSDE');

-- Intern (password: intern123)
INSERT INTO users (name, email, password_hash, role)
VALUES ('Tom Intern', 'intern@example.com', 'intern123', 'Intern');