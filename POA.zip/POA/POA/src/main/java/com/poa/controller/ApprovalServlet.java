package com.poa.controller;

import com.poa.dao.ApprovalDAO;
import com.poa.dao.PlanDAO;
import com.poa.dao.PlanDeliverableDAO;
import com.poa.dao.UserDAO;
import com.poa.model.Approval;
import com.poa.model.Plan;
import com.poa.model.PlanDeliverable;
import com.poa.model.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

/**
 * Servlet to handle approval-related operations
 */
public class ApprovalServlet extends HttpServlet {
    
    private PlanDAO planDAO;
    private PlanDeliverableDAO deliverableDAO;
    private ApprovalDAO approvalDAO;
    private UserDAO userDAO;
    
    @Override
    public void init() throws ServletException {
        planDAO = new PlanDAO();
        deliverableDAO = new PlanDeliverableDAO();
        approvalDAO = new ApprovalDAO();
        userDAO = new UserDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/";
        }
        
        switch (pathInfo) {
            case "/review":
                showReviewForm(request, response);
                break;
            case "/pending":
                showPendingApprovals(request, response);
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                break;
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/";
        }
        
        switch (pathInfo) {
            case "/process":
                processApproval(request, response);
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                break;
        }
    }
    
    /**
     * Show the review form for a plan
     */
    private void showReviewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Check if user has permission to review plans
        if (currentUser.getRole() != User.UserRole.Team_Lead && 
            currentUser.getRole() != User.UserRole.Manager && 
            currentUser.getRole() != User.UserRole.Admin) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        String planIdStr = request.getParameter("id");
        if (planIdStr == null || planIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        try {
            int planId = Integer.parseInt(planIdStr);
            Plan plan = planDAO.getPlanById(planId);
            
            if (plan == null) {
                // Plan doesn't exist
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                return;
            }
            
            // Get plan deliverables
            List<PlanDeliverable> deliverables = deliverableDAO.getDeliverablesByPlanId(planId);
            
            // Get plan owner details
            User planOwner = userDAO.getUserById(plan.getUserId());
            
            // Get previous approvals
            List<Approval> approvals = approvalDAO.getApprovalsByPlanId(planId);
            
            request.setAttribute("plan", plan);
            request.setAttribute("deliverables", deliverables);
            request.setAttribute("planOwner", planOwner);
            request.setAttribute("approvals", approvals);
            
            // Forward to review form JSP
            String jspPath;
            if (currentUser.getRole() == User.UserRole.Team_Lead) {
                jspPath = "/jsp/teamlead/review_plan.jsp";
            } else {
                jspPath = "/jsp/manager/review_plan.jsp";
            }
            
            request.getRequestDispatcher(jspPath).forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
        }
    }
    
    /**
     * Show pending approvals
     */
    private void showPendingApprovals(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Check if user has permission to review plans
        if (currentUser.getRole() != User.UserRole.Team_Lead && 
            currentUser.getRole() != User.UserRole.Manager && 
            currentUser.getRole() != User.UserRole.Admin) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        // Get pending plans based on role
        List<Plan> pendingPlans;
        
        if (currentUser.getRole() == User.UserRole.Team_Lead) {
            // Team Lead sees all Pending plans
            pendingPlans = planDAO.getPlansByStatus(Plan.PlanStatus.Pending);
        } else {
            // Manager or Admin sees plans that have been approved by Team Lead
            // This would need to be implemented with a more complex query
            // For now, we'll just show all Pending plans
            pendingPlans = planDAO.getPlansByStatus(Plan.PlanStatus.Pending);
        }
        
        request.setAttribute("pendingPlans", pendingPlans);
        
        // Forward to pending approvals JSP
        String jspPath;
        if (currentUser.getRole() == User.UserRole.Team_Lead) {
            jspPath = "/jsp/teamlead/pending_approvals.jsp";
        } else {
            jspPath = "/jsp/manager/pending_approvals.jsp";
        }
        
        request.getRequestDispatcher(jspPath).forward(request, response);
    }
    
    /**
     * Process an approval decision
     */
    private void processApproval(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Check if user has permission to approve plans
        if (currentUser.getRole() != User.UserRole.Team_Lead && 
            currentUser.getRole() != User.UserRole.Manager && 
            currentUser.getRole() != User.UserRole.Admin) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        String planIdStr = request.getParameter("planId");
        String statusStr = request.getParameter("status");
        String comments = request.getParameter("comments");
        
        if (planIdStr == null || planIdStr.trim().isEmpty() || 
            statusStr == null || statusStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        try {
            int planId = Integer.parseInt(planIdStr);
            Plan plan = planDAO.getPlanById(planId);
            
            if (plan == null) {
                // Plan doesn't exist
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                return;
            }
            
            // Determine the approver role
            Approval.ApproverRole approverRole;
            if (currentUser.getRole() == User.UserRole.Team_Lead) {
                approverRole = Approval.ApproverRole.Team_Lead;
            } else {
                approverRole = Approval.ApproverRole.Manager;
            }
            
            // Determine the approval status
            Approval.ApprovalStatus approvalStatus;
            Plan.PlanStatus newPlanStatus;
            
            switch (statusStr) {
                case "approve":
                    approvalStatus = Approval.ApprovalStatus.Approved;
                    newPlanStatus = Plan.PlanStatus.Approved;
                    break;
                case "reject":
                    approvalStatus = Approval.ApprovalStatus.Rejected;
                    newPlanStatus = Plan.PlanStatus.Rejected;
                    break;
                case "rework":
                    approvalStatus = Approval.ApprovalStatus.Needs_Rework;
                    newPlanStatus = Plan.PlanStatus.Needs_Rework;
                    break;
                default:
                    // Invalid status
                    response.sendRedirect(request.getContextPath() + "/approval/review?id=" + planId);
                    return;
            }
            
            // Create approval record
            Approval approval = new Approval();
            approval.setPlanId(planId);
            approval.setApprovedBy(currentUser.getUserId());
            approval.setRole(approverRole);
            approval.setStatus(approvalStatus);
            approval.setComments(comments);
            approval.setTimestamp(new Timestamp(System.currentTimeMillis()));
            
            approvalDAO.createApproval(approval);
            
            // Update plan status
            plan.setStatus(newPlanStatus);
            planDAO.updatePlan(plan);
            
            // Redirect to pending approvals
            response.sendRedirect(request.getContextPath() + "/approval/pending");
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
        }
    }
}