package com.poa.controller;

import com.poa.dao.UserDAO;
import com.poa.model.User;
import com.poa.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Servlet to handle user login
 */
public class LoginServlet extends HttpServlet {
    
    private UserDAO userDAO;
    
    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("user") != null) {
            // User is already logged in, redirect to appropriate dashboard
            User user = (User) session.getAttribute("user");
            redirectToRoleDashboard(user, request, response);
        } else {
            // User is not logged in, show login page
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        // Validate input
        if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Email and password are required");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }
        
        // Attempt to authenticate
        User user = userDAO.getUserByEmail(email);
        
        if (user != null) {
            // In a real application, use a proper password verification
            // For this example, we'll use a simple verification
            if (PasswordUtil.verifyPassword(password, user.getPasswordHash())) {
                // Authentication successful
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                
                // Redirect to appropriate dashboard based on role
                redirectToRoleDashboard(user, request, response);
            } else {
                // Authentication failed - incorrect password
                request.setAttribute("errorMessage", "Invalid email or password");
                request.getRequestDispatcher("/login.jsp").forward(request, response);
            }
        } else {
            // Authentication failed - user not found
            request.setAttribute("errorMessage", "Invalid email or password");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
    
    /**
     * Redirect user to appropriate dashboard based on role
     * @param user The authenticated user
     * @param request The HTTP request
     * @param response The HTTP response
     * @throws IOException if redirection fails
     */
    private void redirectToRoleDashboard(User user, HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        
        String contextPath = request.getContextPath();
        
        switch (user.getRole()) {
            case Admin:
                response.sendRedirect(contextPath + "/jsp/admin/dashboard.jsp");
                break;
            case Manager:
                response.sendRedirect(contextPath + "/jsp/manager/dashboard.jsp");
                break;
            case Team_Lead:
                response.sendRedirect(contextPath + "/jsp/teamlead/dashboard.jsp");
                break;
            case SDE:
            case JSDE:
            case Intern:
                response.sendRedirect(contextPath + "/jsp/employee/dashboard.jsp");
                break;
            default:
                // Default to home page
                response.sendRedirect(contextPath + "/index.jsp");
                break;
        }
    }
}