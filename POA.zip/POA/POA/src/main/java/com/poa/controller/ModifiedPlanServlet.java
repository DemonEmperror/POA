package com.poa.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.poa.dao.PlanDAO;
import com.poa.dao.PlanDeliverableDAO;
import com.poa.dao.ApprovalDAO;
import com.poa.dao.NotificationDAO;
import com.poa.dao.ProjectDAO;
import com.poa.dao.ProjectMemberDAO;
import com.poa.dao.TemporaryRoleDAO;
import com.poa.model.Plan;
import com.poa.model.PlanDeliverable;
import com.poa.model.User;
import com.poa.model.Project;
import com.poa.model.Notification;

/**
 * Servlet for handling plan-related operations.
 * Updated to support project-based plans and temporary roles.
 */
@WebServlet("/plans/*")
public class PlanServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private PlanDAO planDAO = new PlanDAO();
    private PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
    private ApprovalDAO approvalDAO = new ApprovalDAO();
    private NotificationDAO notificationDAO = new NotificationDAO();
    private ProjectDAO projectDAO = new ProjectDAO();
    private ProjectMemberDAO projectMemberDAO = new ProjectMemberDAO();
    private TemporaryRoleDAO temporaryRoleDAO = new TemporaryRoleDAO();
    
    /**
     * Handles GET requests for plan operations.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // List all plans for the user's active project
                listPlans(request, response);
            } else if (pathInfo.equals("/new")) {
                // Show create plan form
                showCreateForm(request, response);
            } else if (pathInfo.matches("/view/\\d+")) {
                // View plan details
                int planId = Integer.parseInt(pathInfo.substring(6));
                viewPlan(request, response, planId);
            } else if (pathInfo.equals("/history")) {
                // View plan history
                viewPlanHistory(request, response);
            } else if (pathInfo.equals("/pending")) {
                // View pending approvals
                showPendingApprovals(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            handleError(request, response, e);
        }
    }
    
    /**
     * Handles POST requests for plan operations.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // Create new plan
                createPlan(request, response);
            } else if (pathInfo.matches("/update/\\d+")) {
                // Update existing plan
                int planId = Integer.parseInt(pathInfo.substring(8));
                updatePlan(request, response, planId);
            } else if (pathInfo.matches("/delete/\\d+")) {
                // Delete plan
                int planId = Integer.parseInt(pathInfo.substring(8));
                deletePlan(request, response, planId);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            handleError(request, response, e);
        } catch (ParseException e) {
            request.setAttribute("errorMessage", "Invalid date format: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
        }
    }
    
    /**
     * Lists all plans for the user's active project.
     */
    private void listPlans(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        Project activeProject = (Project) session.getAttribute("activeProject");
        
        if (activeProject == null) {
            // If no active project, redirect to project selection
            request.setAttribute("message", "Please select a project first");
            request.getRequestDispatcher("/WEB-INF/views/project/select.jsp").forward(request, response);
            return;
        }
        
        List<Plan> plans;
        
        // Determine which plans to show based on role
        if (currentUser.getRole().equals("Admin")) {
            // Admin sees all plans in the active project
            plans = planDAO.getPlansByProjectId(activeProject.getProjectId());
        } else if (currentUser.getRole().equals("Manager") || 
                  temporaryRoleDAO.hasActiveTemporaryManagerRole(currentUser.getUserId(), activeProject.getProjectId())) {
            // Manager or temporary manager sees all plans in the project
            plans = planDAO.getPlansByProjectId(activeProject.getProjectId());
        } else if (currentUser.getRole().equals("Team Lead")) {
            // Team Lead sees plans for their team members in the project
            plans = planDAO.getPlansByProjectIdForTeamLead(activeProject.getProjectId(), currentUser.getUserId());
        } else {
            // Regular users see only their own plans
            plans = planDAO.getPlansByUserIdAndProjectId(currentUser.getUserId(), activeProject.getProjectId());
        }
        
        request.setAttribute("plans", plans);
        request.setAttribute("activeProject", activeProject);
        request.getRequestDispatcher("/WEB-INF/views/plan/list.jsp").forward(request, response);
    }
    
    /**
     * Shows the create plan form.
     */
    private void showCreateForm(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        Project activeProject = (Project) session.getAttribute("activeProject");
        
        if (activeProject == null) {
            // If no active project, redirect to project selection
            request.setAttribute("message", "Please select a project first");
            request.getRequestDispatcher("/WEB-INF/views/project/select.jsp").forward(request, response);
            return;
        }
        
        // Check if user is a member of the active project
        if (!projectMemberDAO.isUserMemberOfProject(activeProject.getProjectId(), currentUser.getUserId())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Set today's date as default
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String today = dateFormat.format(new Date());
        
        request.setAttribute("today", today);
        request.setAttribute("activeProject", activeProject);
        request.getRequestDispatcher("/WEB-INF/views/plan/create.jsp").forward(request, response);
    }
    
    /**
     * Views plan details.
     */
    private void viewPlan(HttpServletRequest request, HttpServletResponse response, int planId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Plan plan = planDAO.getPlanById(planId);
        
        if (plan == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to view this plan
        boolean hasPermission = false;
        
        if (currentUser.getRole().equals("Admin")) {
            hasPermission = true;
        } else if (plan.getUserId() == currentUser.getUserId()) {
            // User can view their own plans
            hasPermission = true;
        } else if (currentUser.getRole().equals("Manager") || 
                  temporaryRoleDAO.hasActiveTemporaryManagerRole(currentUser.getUserId(), plan.getProjectId())) {
            // Manager or temporary manager can view all plans in their projects
            hasPermission = true;
        } else if (currentUser.getRole().equals("Team Lead")) {
            // Team Lead can view plans for their team members
            hasPermission = planDAO.isTeamLeadForPlan(currentUser.getUserId(), planId);
        }
        
        if (!hasPermission) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Get plan deliverables
        List<PlanDeliverable> deliverables = deliverableDAO.getDeliverablesByPlanId(planId);
        
        // Get project
        Project project = projectDAO.getProjectById(plan.getProjectId());
        
        request.setAttribute("plan", plan);
        request.setAttribute("deliverables", deliverables);
        request.setAttribute("project", project);
        request.getRequestDispatcher("/WEB-INF/views/plan/view.jsp").forward(request, response);
    }
    
    /**
     * Views plan history.
     */
    private void viewPlanHistory(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        Project activeProject = (Project) session.getAttribute("activeProject");
        
        if (activeProject == null) {
            // If no active project, redirect to project selection
            request.setAttribute("message", "Please select a project first");
            request.getRequestDispatcher("/WEB-INF/views/project/select.jsp").forward(request, response);
            return;
        }
        
        // Get filter parameters
        String userIdParam = request.getParameter("userId");
        String startDateParam = request.getParameter("startDate");
        String endDateParam = request.getParameter("endDate");
        String statusParam = request.getParameter("status");
        
        int userId = 0;
        Date startDate = null;
        Date endDate = null;
        String status = null;
        
        // Parse user ID
        if (userIdParam != null && !userIdParam.isEmpty()) {
            try {
                userId = Integer.parseInt(userIdParam);
            } catch (NumberFormatException e) {
                // Ignore parsing error
            }
        }
        
        // Parse dates
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        if (startDateParam != null && !startDateParam.isEmpty()) {
            try {
                startDate = dateFormat.parse(startDateParam);
            } catch (ParseException e) {
                // Ignore parsing error
            }
        }
        
        if (endDateParam != null && !endDateParam.isEmpty()) {
            try {
                endDate = dateFormat.parse(endDateParam);
            } catch (ParseException e) {
                // Ignore parsing error
            }
        }
        
        // Parse status
        if (statusParam != null && !statusParam.isEmpty()) {
            status = statusParam;
        }
        
        List<Plan> plans;
        
        // Determine which plans to show based on role
        if (currentUser.getRole().equals("Admin")) {
            // Admin sees all plans in the active project
            plans = planDAO.getPlansByProjectIdWithFilters(activeProject.getProjectId(), userId, startDate, endDate, status);
        } else if (currentUser.getRole().equals("Manager") || 
                  temporaryRoleDAO.hasActiveTemporaryManagerRole(currentUser.getUserId(), activeProject.getProjectId())) {
            // Manager or temporary manager sees all plans in the project
            plans = planDAO.getPlansByProjectIdWithFilters(activeProject.getProjectId(), userId, startDate, endDate, status);
        } else if (currentUser.getRole().equals("Team Lead")) {
            // Team Lead sees plans for their team members in the project
            plans = planDAO.getPlansByProjectIdForTeamLeadWithFilters(activeProject.getProjectId(), currentUser.getUserId(), userId, startDate, endDate, status);
        } else {
            // Regular users see only their own plans
            plans = planDAO.getPlansByUserIdAndProjectIdWithFilters(currentUser.getUserId(), activeProject.getProjectId(), startDate, endDate, status);
        }
        
        request.setAttribute("plans", plans);
        request.setAttribute("activeProject", activeProject);
        request.setAttribute("selectedUserId", userId);
        request.setAttribute("startDate", startDateParam);
        request.setAttribute("endDate", endDateParam);
        request.setAttribute("status", status);
        
        // Get list of users for filter (if user has permission)
        if (currentUser.getRole().equals("Admin") || 
            currentUser.getRole().equals("Manager") || 
            currentUser.getRole().equals("Team Lead") ||
            temporaryRoleDAO.hasActiveTemporaryManagerRole(currentUser.getUserId(), activeProject.getProjectId())) {
            
            List<User> users = projectMemberDAO.getProjectMemberUsers(activeProject.getProjectId());
            request.setAttribute("users", users);
        }
        
        request.getRequestDispatcher("/WEB-INF/views/plan/history.jsp").forward(request, response);
    }
    
    /**
     * Shows pending approvals.
     */
    private void showPendingApprovals(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        Project activeProject = (Project) session.getAttribute("activeProject");
        
        if (activeProject == null) {
            // If no active project, redirect to project selection
            request.setAttribute("message", "Please select a project first");
            request.getRequestDispatcher("/WEB-INF/views/project/select.jsp").forward(request, response);
            return;
        }
        
        List<Plan> pendingPlans = new ArrayList<>();
        
        // Team Lead sees plans pending their approval
        if (currentUser.getRole().equals("Team Lead")) {
            pendingPlans = planDAO.getPendingPlansForTeamLead(activeProject.getProjectId(), currentUser.getUserId());
        }
        
        // Manager or temporary manager sees plans pending their approval (after Team Lead approval)
        if (currentUser.getRole().equals("Manager") || 
            temporaryRoleDAO.hasActiveTemporaryManagerRole(currentUser.getUserId(), activeProject.getProjectId())) {
            pendingPlans = planDAO.getPendingPlansForManager(activeProject.getProjectId());
        }
        
        request.setAttribute("pendingPlans", pendingPlans);
        request.setAttribute("activeProject", activeProject);
        request.getRequestDispatcher("/WEB-INF/views/plan/pending.jsp").forward(request, response);
    }
    
    /**
     * Creates a new plan.
     */
    private void createPlan(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException, ParseException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        Project activeProject = (Project) session.getAttribute("activeProject");
        
        if (activeProject == null) {
            // If no active project, redirect to project selection
            request.setAttribute("message", "Please select a project first");
            request.getRequestDispatcher("/WEB-INF/views/project/select.jsp").forward(request, response);
            return;
        }
        
        // Check if user is a member of the active project
        if (!projectMemberDAO.isUserMemberOfProject(activeProject.getProjectId(), currentUser.getUserId())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Parse date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date planDate = dateFormat.parse(request.getParameter("date"));
        
        // Create plan
        Plan plan = new Plan();
        plan.setUserId(currentUser.getUserId());
        plan.setProjectId(activeProject.getProjectId());
        plan.setDate(new java.sql.Date(planDate.getTime()));
        plan.setStatus("Pending");
        
        plan = planDAO.createPlan(plan);
        
        // Get deliverable parameters
        String[] descriptions = request.getParameterValues("description");
        String[] estimatedTimes = request.getParameterValues("estimatedTime");
        
        if (descriptions != null && estimatedTimes != null) {
            for (int i = 0; i < descriptions.length; i++) {
                if (descriptions[i] != null && !descriptions[i].trim().isEmpty()) {
                    PlanDeliverable deliverable = new PlanDeliverable();
                    deliverable.setPlanId(plan.getPlanId());
                    deliverable.setDescription(descriptions[i]);
                    deliverable.setEstimatedTime(Double.parseDouble(estimatedTimes[i]));
                    
                    deliverableDAO.createDeliverable(deliverable);
                }
            }
        }
        
        // Create notifications for Team Leads
        List<User> teamLeads = projectMemberDAO.getProjectMembersByRole(activeProject.getProjectId(), "Team Lead");
        for (User teamLead : teamLeads) {
            Notification notification = new Notification(
                teamLead.getUserId(),
                "New plan submitted by " + currentUser.getName() + " for " + dateFormat.format(planDate) + " requires your approval",
                "Plan"
            );
            notificationDAO.createNotification(notification);
        }
        
        response.sendRedirect(request.getContextPath() + "/plans/view/" + plan.getPlanId());
    }
    
    /**
     * Updates an existing plan.
     */
    private void updatePlan(HttpServletRequest request, HttpServletResponse response, int planId) 
            throws SQLException, ServletException, IOException, ParseException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Plan plan = planDAO.getPlanById(planId);
        
        if (plan == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to update this plan
        if (plan.getUserId() != currentUser.getUserId()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Check if plan can be updated (only if status is Pending or Needs Rework)
        if (!plan.getStatus().equals("Pending") && !plan.getStatus().equals("Needs Rework")) {
            request.setAttribute("errorMessage", "This plan cannot be updated because it has already been " + plan.getStatus().toLowerCase());
            viewPlan(request, response, planId);
            return;
        }
        
        // Get existing deliverables
        List<PlanDeliverable> existingDeliverables = deliverableDAO.getDeliverablesByPlanId(planId);
        
        // Delete existing deliverables
        for (PlanDeliverable deliverable : existingDeliverables) {
            deliverableDAO.deleteDeliverable(deliverable.getDeliverableId());
        }
        
        // Get deliverable parameters
        String[] descriptions = request.getParameterValues("description");
        String[] estimatedTimes = request.getParameterValues("estimatedTime");
        
        if (descriptions != null && estimatedTimes != null) {
            for (int i = 0; i < descriptions.length; i++) {
                if (descriptions[i] != null && !descriptions[i].trim().isEmpty()) {
                    PlanDeliverable deliverable = new PlanDeliverable();
                    deliverable.setPlanId(planId);
                    deliverable.setDescription(descriptions[i]);
                    deliverable.setEstimatedTime(Double.parseDouble(estimatedTimes[i]));
                    
                    deliverableDAO.createDeliverable(deliverable);
                }
            }
        }
        
        // If plan was in "Needs Rework" status, change it back to "Pending"
        if (plan.getStatus().equals("Needs Rework")) {
            plan.setStatus("Pending");
            planDAO.updatePlanStatus(planId, "Pending");
            
            // Create notifications for Team Leads
            List<User> teamLeads = projectMemberDAO.getProjectMembersByRole(plan.getProjectId(), "Team Lead");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            for (User teamLead : teamLeads) {
                Notification notification = new Notification(
                    teamLead.getUserId(),
                    "Plan by " + currentUser.getName() + " for " + dateFormat.format(plan.getDate()) + " has been updated and requires your approval",
                    "Plan"
                );
                notificationDAO.createNotification(notification);
            }
        }
        
        response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
    }
    
    /**
     * Deletes a plan.
     */
    private void deletePlan(HttpServletRequest request, HttpServletResponse response, int planId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Plan plan = planDAO.getPlanById(planId);
        
        if (plan == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to delete this plan
        if (plan.getUserId() != currentUser.getUserId() && !currentUser.getRole().equals("Admin")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Check if plan can be deleted (only if status is Pending or Needs Rework)
        if (!plan.getStatus().equals("Pending") && !plan.getStatus().equals("Needs Rework") && !currentUser.getRole().equals("Admin")) {
            request.setAttribute("errorMessage", "This plan cannot be deleted because it has already been " + plan.getStatus().toLowerCase());
            viewPlan(request, response, planId);
            return;
        }
        
        // Get existing deliverables
        List<PlanDeliverable> existingDeliverables = deliverableDAO.getDeliverablesByPlanId(planId);
        
        // Delete existing deliverables
        for (PlanDeliverable deliverable : existingDeliverables) {
            deliverableDAO.deleteDeliverable(deliverable.getDeliverableId());
        }
        
        // Delete plan
        planDAO.deletePlan(planId);
        
        response.sendRedirect(request.getContextPath() + "/plans");
    }
    
    /**
     * Handles errors.
     */
    private void handleError(HttpServletRequest request, HttpServletResponse response, Exception e) 
            throws ServletException, IOException {
        e.printStackTrace();
        request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
        request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
    }
}