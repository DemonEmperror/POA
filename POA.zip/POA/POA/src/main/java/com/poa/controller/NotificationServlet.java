package com.poa.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.poa.dao.NotificationDAO;
import com.poa.model.Notification;
import com.poa.model.User;

/**
 * Servlet for handling notification-related operations.
 */
@WebServlet("/notifications/*")
public class NotificationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private NotificationDAO notificationDAO = new NotificationDAO();
    
    /**
     * Handles GET requests for notification operations.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // List all notifications
                listNotifications(request, response);
            } else if (pathInfo.equals("/unread")) {
                // List unread notifications
                listUnreadNotifications(request, response);
            } else if (pathInfo.equals("/count")) {
                // Get unread notification count (for AJAX)
                getUnreadCount(request, response);
            } else if (pathInfo.matches("/read/\\d+")) {
                // Mark a notification as read
                int notificationId = Integer.parseInt(pathInfo.substring(6));
                markAsRead(request, response, notificationId);
            } else if (pathInfo.equals("/markAllRead")) {
                // Mark all notifications as read
                markAllAsRead(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            handleError(request, response, e);
        }
    }
    
    /**
     * Handles POST requests for notification operations.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo != null && pathInfo.matches("/delete/\\d+")) {
                // Delete a notification
                int notificationId = Integer.parseInt(pathInfo.substring(8));
                deleteNotification(request, response, notificationId);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            handleError(request, response, e);
        }
    }
    
    /**
     * Lists all notifications for the current user.
     */
    private void listNotifications(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Get parameter for limit (default 20)
        int limit = 20;
        String limitParam = request.getParameter("limit");
        if (limitParam != null && !limitParam.isEmpty()) {
            try {
                limit = Integer.parseInt(limitParam);
            } catch (NumberFormatException e) {
                // Use default if parsing fails
            }
        }
        
        List<Notification> notifications = notificationDAO.getUserNotifications(currentUser.getUserId(), limit, false);
        request.setAttribute("notifications", notifications);
        
        request.getRequestDispatcher("/WEB-INF/views/notification/list.jsp").forward(request, response);
    }
    
    /**
     * Lists unread notifications for the current user.
     */
    private void listUnreadNotifications(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        List<Notification> notifications = notificationDAO.getUserNotifications(currentUser.getUserId(), 0, true);
        request.setAttribute("notifications", notifications);
        
        request.getRequestDispatcher("/WEB-INF/views/notification/unread.jsp").forward(request, response);
    }
    
    /**
     * Gets the count of unread notifications (for AJAX).
     */
    private void getUnreadCount(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        int count = notificationDAO.countUnreadNotifications(currentUser.getUserId());
        
        response.setContentType("application/json");
        response.getWriter().write("{\"count\": " + count + "}");
    }
    
    /**
     * Marks a notification as read.
     */
    private void markAsRead(HttpServletRequest request, HttpServletResponse response, int notificationId) 
            throws SQLException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Notification notification = notificationDAO.getNotificationById(notificationId);
        
        if (notification == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if this notification belongs to the current user
        if (notification.getUserId() != currentUser.getUserId()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        notificationDAO.markAsRead(notificationId);
        
        // If AJAX request, return success response
        if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": true}");
        } else {
            // Otherwise redirect back to notifications
            String referer = request.getHeader("Referer");
            if (referer != null) {
                response.sendRedirect(referer);
            } else {
                response.sendRedirect(request.getContextPath() + "/notifications");
            }
        }
    }
    
    /**
     * Marks all notifications as read.
     */
    private void markAllAsRead(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        int count = notificationDAO.markAllAsRead(currentUser.getUserId());
        
        // If AJAX request, return success response
        if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": true, \"count\": " + count + "}");
        } else {
            // Otherwise redirect back to notifications
            String referer = request.getHeader("Referer");
            if (referer != null) {
                response.sendRedirect(referer);
            } else {
                response.sendRedirect(request.getContextPath() + "/notifications");
            }
        }
    }
    
    /**
     * Deletes a notification.
     */
    private void deleteNotification(HttpServletRequest request, HttpServletResponse response, int notificationId) 
            throws SQLException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Notification notification = notificationDAO.getNotificationById(notificationId);
        
        if (notification == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if this notification belongs to the current user
        if (notification.getUserId() != currentUser.getUserId()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        notificationDAO.deleteNotification(notificationId);
        
        // If AJAX request, return success response
        if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": true}");
        } else {
            // Otherwise redirect back to notifications
            String referer = request.getHeader("Referer");
            if (referer != null) {
                response.sendRedirect(referer);
            } else {
                response.sendRedirect(request.getContextPath() + "/notifications");
            }
        }
    }
    
    /**
     * Handles errors.
     */
    private void handleError(HttpServletRequest request, HttpServletResponse response, Exception e) 
            throws ServletException, IOException {
        e.printStackTrace();
        
        // If AJAX request, return error response
        if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"" + e.getMessage() + "\"}");
        } else {
            // Otherwise show error page
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
        }
    }
}