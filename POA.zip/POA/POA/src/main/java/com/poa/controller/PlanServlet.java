package com.poa.controller;

import com.poa.dao.PlanDAO;
import com.poa.dao.PlanDeliverableDAO;
import com.poa.model.Plan;
import com.poa.model.PlanDeliverable;
import com.poa.model.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet to handle plan-related operations
 */
public class PlanServlet extends HttpServlet {
    
    private PlanDAO planDAO;
    private PlanDeliverableDAO deliverableDAO;
    
    @Override
    public void init() throws ServletException {
        planDAO = new PlanDAO();
        deliverableDAO = new PlanDeliverableDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/";
        }
        
        switch (pathInfo) {
            case "/create":
                showCreatePlanForm(request, response);
                break;
            case "/edit":
                showEditPlanForm(request, response);
                break;
            case "/view":
                viewPlan(request, response);
                break;
            case "/history":
                viewPlanHistory(request, response);
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                break;
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/";
        }
        
        switch (pathInfo) {
            case "/create":
                createPlan(request, response);
                break;
            case "/update":
                updatePlan(request, response);
                break;
            case "/delete":
                deletePlan(request, response);
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                break;
        }
    }
    
    /**
     * Show the create plan form
     */
    private void showCreatePlanForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Check if user already has a plan for today
        LocalDate today = LocalDate.now();
        Date todayDate = Date.valueOf(today);
        List<Plan> todaysPlans = planDAO.getPlansByUserAndDate(currentUser.getUserId(), todayDate);
        
        if (!todaysPlans.isEmpty()) {
            // User already has a plan for today, redirect to view it
            Plan existingPlan = todaysPlans.get(0);
            response.sendRedirect(request.getContextPath() + "/plan/view?id=" + existingPlan.getPlanId());
            return;
        }
        
        // Forward to create plan JSP
        request.getRequestDispatcher("/jsp/employee/create_plan.jsp").forward(request, response);
    }
    
    /**
     * Show the edit plan form
     */
    private void showEditPlanForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String planIdStr = request.getParameter("id");
        if (planIdStr == null || planIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        try {
            int planId = Integer.parseInt(planIdStr);
            Plan plan = planDAO.getPlanById(planId);
            
            if (plan == null || plan.getUserId() != currentUser.getUserId()) {
                // Plan doesn't exist or doesn't belong to current user
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                return;
            }
            
            if (plan.getStatus() != Plan.PlanStatus.Pending) {
                // Plan is not in Pending status, can't edit
                request.setAttribute("errorMessage", "You can only edit plans in Pending status.");
                response.sendRedirect(request.getContextPath() + "/plan/view?id=" + planId);
                return;
            }
            
            // Get plan deliverables
            List<PlanDeliverable> deliverables = deliverableDAO.getDeliverablesByPlanId(planId);
            request.setAttribute("plan", plan);
            request.setAttribute("deliverables", deliverables);
            
            // Forward to edit plan JSP
            request.getRequestDispatcher("/jsp/employee/edit_plan.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
        }
    }
    
    /**
     * View a specific plan
     */
    private void viewPlan(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String planIdStr = request.getParameter("id");
        if (planIdStr == null || planIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        try {
            int planId = Integer.parseInt(planIdStr);
            Plan plan = planDAO.getPlanById(planId);
            
            if (plan == null) {
                // Plan doesn't exist
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                return;
            }
            
            // Check if user has permission to view this plan
            boolean hasPermission = false;
            
            if (plan.getUserId() == currentUser.getUserId()) {
                // User is the owner of the plan
                hasPermission = true;
            } else if (currentUser.getRole() == User.UserRole.Team_Lead || 
                      currentUser.getRole() == User.UserRole.Manager || 
                      currentUser.getRole() == User.UserRole.Admin) {
                // User is a Team Lead, Manager, or Admin
                hasPermission = true;
            }
            
            if (!hasPermission) {
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                return;
            }
            
            // Get plan deliverables
            List<PlanDeliverable> deliverables = deliverableDAO.getDeliverablesByPlanId(planId);
            request.setAttribute("plan", plan);
            request.setAttribute("deliverables", deliverables);
            
            // Forward to view plan JSP
            request.getRequestDispatcher("/jsp/employee/view_plan.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
        }
    }
    
    /**
     * View plan history
     */
    private void viewPlanHistory(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Get user's plans
        List<Plan> userPlans = planDAO.getPlansByUserId(currentUser.getUserId());
        request.setAttribute("plans", userPlans);
        
        // Forward to plan history JSP
        request.getRequestDispatcher("/jsp/employee/plan_history.jsp").forward(request, response);
    }
    
    /**
     * Create a new plan
     */
    private void createPlan(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Check if user already has a plan for today
        LocalDate today = LocalDate.now();
        Date todayDate = Date.valueOf(today);
        List<Plan> todaysPlans = planDAO.getPlansByUserAndDate(currentUser.getUserId(), todayDate);
        
        if (!todaysPlans.isEmpty()) {
            // User already has a plan for today, redirect to view it
            Plan existingPlan = todaysPlans.get(0);
            response.sendRedirect(request.getContextPath() + "/plan/view?id=" + existingPlan.getPlanId());
            return;
        }
        
        // Create new plan
        Plan plan = new Plan();
        plan.setUserId(currentUser.getUserId());
        plan.setDate(todayDate);
        plan.setStatus(Plan.PlanStatus.Pending);
        
        Plan createdPlan = planDAO.createPlan(plan);
        
        if (createdPlan == null) {
            // Failed to create plan
            request.setAttribute("errorMessage", "Failed to create plan. Please try again.");
            request.getRequestDispatcher("/jsp/employee/create_plan.jsp").forward(request, response);
            return;
        }
        
        // Process deliverables
        String[] descriptions = request.getParameterValues("description");
        String[] estimatedTimes = request.getParameterValues("estimatedTime");
        
        if (descriptions != null && estimatedTimes != null && descriptions.length == estimatedTimes.length) {
            List<PlanDeliverable> deliverables = new ArrayList<>();
            
            for (int i = 0; i < descriptions.length; i++) {
                if (descriptions[i] != null && !descriptions[i].trim().isEmpty() &&
                    estimatedTimes[i] != null && !estimatedTimes[i].trim().isEmpty()) {
                    
                    PlanDeliverable deliverable = new PlanDeliverable();
                    deliverable.setPlanId(createdPlan.getPlanId());
                    deliverable.setDescription(descriptions[i].trim());
                    deliverable.setEstimatedTime(new BigDecimal(estimatedTimes[i].trim()));
                    deliverable.setRework(PlanDeliverable.StatusEnum.None);
                    deliverable.setAchieved(PlanDeliverable.StatusEnum.None);
                    
                    deliverables.add(deliverable);
                }
            }
            
            if (!deliverables.isEmpty()) {
                for (PlanDeliverable deliverable : deliverables) {
                    deliverableDAO.createDeliverable(deliverable);
                }
            }
        }
        
        // Redirect to view the created plan
        response.sendRedirect(request.getContextPath() + "/plan/view?id=" + createdPlan.getPlanId());
    }
    
    /**
     * Update an existing plan
     */
    private void updatePlan(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String planIdStr = request.getParameter("planId");
        if (planIdStr == null || planIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        try {
            int planId = Integer.parseInt(planIdStr);
            Plan plan = planDAO.getPlanById(planId);
            
            if (plan == null || plan.getUserId() != currentUser.getUserId()) {
                // Plan doesn't exist or doesn't belong to current user
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                return;
            }
            
            if (plan.getStatus() != Plan.PlanStatus.Pending && plan.getStatus() != Plan.PlanStatus.Needs_Rework) {
                // Plan is not in Pending or Needs Rework status, can't update
                request.setAttribute("errorMessage", "You can only update plans in Pending or Needs Rework status.");
                response.sendRedirect(request.getContextPath() + "/plan/view?id=" + planId);
                return;
            }
            
            // Reset status to Pending if it was Needs Rework
            if (plan.getStatus() == Plan.PlanStatus.Needs_Rework) {
                plan.setStatus(Plan.PlanStatus.Pending);
                planDAO.updatePlan(plan);
            }
            
            // Process existing deliverables
            String[] deliverableIds = request.getParameterValues("deliverableId");
            String[] descriptions = request.getParameterValues("description");
            String[] estimatedTimes = request.getParameterValues("estimatedTime");
            String[] actualTimes = request.getParameterValues("actualTime");
            String[] overflowHours = request.getParameterValues("overflowHours");
            String[] reworks = request.getParameterValues("rework");
            String[] achieved = request.getParameterValues("achieved");
            
            if (deliverableIds != null) {
                for (int i = 0; i < deliverableIds.length; i++) {
                    int deliverableId = Integer.parseInt(deliverableIds[i]);
                    PlanDeliverable deliverable = deliverableDAO.getDeliverableById(deliverableId);
                    
                    if (deliverable != null && deliverable.getPlanId() == planId) {
                        deliverable.setDescription(descriptions[i].trim());
                        deliverable.setEstimatedTime(new BigDecimal(estimatedTimes[i].trim()));
                        
                        if (actualTimes[i] != null && !actualTimes[i].trim().isEmpty()) {
                            deliverable.setActualTime(new BigDecimal(actualTimes[i].trim()));
                        }
                        
                        if (overflowHours[i] != null && !overflowHours[i].trim().isEmpty()) {
                            deliverable.setOverflowHours(new BigDecimal(overflowHours[i].trim()));
                        }
                        
                        if (reworks[i] != null) {
                            deliverable.setRework(PlanDeliverable.StatusEnum.valueOf(reworks[i]));
                        }
                        
                        if (achieved[i] != null) {
                            deliverable.setAchieved(PlanDeliverable.StatusEnum.valueOf(achieved[i]));
                        }
                        
                        deliverableDAO.updateDeliverable(deliverable);
                    }
                }
            }
            
            // Process new deliverables
            String[] newDescriptions = request.getParameterValues("newDescription");
            String[] newEstimatedTimes = request.getParameterValues("newEstimatedTime");
            
            if (newDescriptions != null && newEstimatedTimes != null && 
                newDescriptions.length == newEstimatedTimes.length) {
                
                for (int i = 0; i < newDescriptions.length; i++) {
                    if (newDescriptions[i] != null && !newDescriptions[i].trim().isEmpty() &&
                        newEstimatedTimes[i] != null && !newEstimatedTimes[i].trim().isEmpty()) {
                        
                        PlanDeliverable deliverable = new PlanDeliverable();
                        deliverable.setPlanId(planId);
                        deliverable.setDescription(newDescriptions[i].trim());
                        deliverable.setEstimatedTime(new BigDecimal(newEstimatedTimes[i].trim()));
                        deliverable.setRework(PlanDeliverable.StatusEnum.None);
                        deliverable.setAchieved(PlanDeliverable.StatusEnum.None);
                        
                        deliverableDAO.createDeliverable(deliverable);
                    }
                }
            }
            
            // Process deleted deliverables
            String[] deleteIds = request.getParameterValues("deleteDeliverable");
            if (deleteIds != null) {
                for (String deleteId : deleteIds) {
                    int deliverableId = Integer.parseInt(deleteId);
                    PlanDeliverable deliverable = deliverableDAO.getDeliverableById(deliverableId);
                    
                    if (deliverable != null && deliverable.getPlanId() == planId) {
                        deliverableDAO.deleteDeliverable(deliverableId);
                    }
                }
            }
            
            // Redirect to view the updated plan
            response.sendRedirect(request.getContextPath() + "/plan/view?id=" + planId);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
        }
    }
    
    /**
     * Delete a plan
     */
    private void deletePlan(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String planIdStr = request.getParameter("id");
        if (planIdStr == null || planIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            return;
        }
        
        try {
            int planId = Integer.parseInt(planIdStr);
            Plan plan = planDAO.getPlanById(planId);
            
            if (plan == null || plan.getUserId() != currentUser.getUserId()) {
                // Plan doesn't exist or doesn't belong to current user
                response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
                return;
            }
            
            if (plan.getStatus() != Plan.PlanStatus.Pending) {
                // Plan is not in Pending status, can't delete
                request.setAttribute("errorMessage", "You can only delete plans in Pending status.");
                response.sendRedirect(request.getContextPath() + "/plan/view?id=" + planId);
                return;
            }
            
            // Delete all deliverables first
            List<PlanDeliverable> deliverables = deliverableDAO.getDeliverablesByPlanId(planId);
            for (PlanDeliverable deliverable : deliverables) {
                deliverableDAO.deleteDeliverable(deliverable.getDeliverableId());
            }
            
            // Delete the plan
            planDAO.deletePlan(planId);
            
            // Redirect to dashboard
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/jsp/employee/dashboard.jsp");
        }
    }
}