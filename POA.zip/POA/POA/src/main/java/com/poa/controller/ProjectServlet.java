package com.poa.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.poa.dao.ProjectDAO;
import com.poa.dao.ProjectMemberDAO;
import com.poa.dao.NotificationDAO;
import com.poa.model.Project;
import com.poa.model.ProjectMember;
import com.poa.model.User;
import com.poa.model.Notification;

/**
 * Servlet for handling project-related operations.
 */
@WebServlet("/projects/*")
public class ProjectServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private ProjectDAO projectDAO = new ProjectDAO();
    private ProjectMemberDAO projectMemberDAO = new ProjectMemberDAO();
    private NotificationDAO notificationDAO = new NotificationDAO();
    
    /**
     * Handles GET requests for project operations.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // List all projects
                listProjects(request, response);
            } else if (pathInfo.equals("/new")) {
                // Show create project form
                showCreateForm(request, response);
            } else if (pathInfo.matches("/edit/\\d+")) {
                // Show edit project form
                int projectId = Integer.parseInt(pathInfo.substring(6));
                showEditForm(request, response, projectId);
            } else if (pathInfo.matches("/view/\\d+")) {
                // View project details
                int projectId = Integer.parseInt(pathInfo.substring(6));
                viewProject(request, response, projectId);
            } else if (pathInfo.matches("/members/\\d+")) {
                // View project members
                int projectId = Integer.parseInt(pathInfo.substring(9));
                viewProjectMembers(request, response, projectId);
            } else if (pathInfo.equals("/switch")) {
                // Switch active project
                switchProject(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            handleError(request, response, e);
        }
    }
    
    /**
     * Handles POST requests for project operations.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // Create new project
                createProject(request, response);
            } else if (pathInfo.matches("/update/\\d+")) {
                // Update existing project
                int projectId = Integer.parseInt(pathInfo.substring(8));
                updateProject(request, response, projectId);
            } else if (pathInfo.matches("/delete/\\d+")) {
                // Delete project
                int projectId = Integer.parseInt(pathInfo.substring(8));
                deleteProject(request, response, projectId);
            } else if (pathInfo.equals("/addMember")) {
                // Add member to project
                addMemberToProject(request, response);
            } else if (pathInfo.equals("/removeMember")) {
                // Remove member from project
                removeMemberFromProject(request, response);
            } else if (pathInfo.equals("/updateMemberRole")) {
                // Update member's role in project
                updateMemberRole(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            handleError(request, response, e);
        }
    }
    
    /**
     * Lists all projects the user has access to.
     */
    private void listProjects(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        List<Project> projects;
        
        if (currentUser.getRole().equals("Admin")) {
            // Admins can see all projects
            projects = projectDAO.getAllProjects();
        } else {
            // Other users see only their projects
            projects = projectDAO.getProjectsByUserId(currentUser.getUserId());
        }
        
        request.setAttribute("projects", projects);
        request.getRequestDispatcher("/WEB-INF/views/project/list.jsp").forward(request, response);
    }
    
    /**
     * Shows the create project form.
     */
    private void showCreateForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Only Managers and Admins can create projects
        if (currentUser.getRole().equals("Manager") || currentUser.getRole().equals("Admin")) {
            request.getRequestDispatcher("/WEB-INF/views/project/create.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }
    
    /**
     * Shows the edit project form.
     */
    private void showEditForm(HttpServletRequest request, HttpServletResponse response, int projectId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Project project = projectDAO.getProjectById(projectId);
        
        if (project == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to edit this project
        if (currentUser.getRole().equals("Admin") || 
            (projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId()) != null && 
             projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId()).equals("Project Manager"))) {
            
            request.setAttribute("project", project);
            request.getRequestDispatcher("/WEB-INF/views/project/edit.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }
    
    /**
     * Views project details.
     */
    private void viewProject(HttpServletRequest request, HttpServletResponse response, int projectId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Project project = projectDAO.getProjectById(projectId);
        
        if (project == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has access to this project
        if (currentUser.getRole().equals("Admin") || projectMemberDAO.isUserMemberOfProject(projectId, currentUser.getUserId())) {
            request.setAttribute("project", project);
            
            // Set this project as the active project in session
            session.setAttribute("activeProject", project);
            
            // Get project members
            List<ProjectMember> members = projectMemberDAO.getProjectMembers(projectId);
            request.setAttribute("members", members);
            
            request.getRequestDispatcher("/WEB-INF/views/project/view.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }
    
    /**
     * Views project members.
     */
    private void viewProjectMembers(HttpServletRequest request, HttpServletResponse response, int projectId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Project project = projectDAO.getProjectById(projectId);
        
        if (project == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has access to this project
        if (currentUser.getRole().equals("Admin") || projectMemberDAO.isUserMemberOfProject(projectId, currentUser.getUserId())) {
            request.setAttribute("project", project);
            
            // Get project members
            List<ProjectMember> members = projectMemberDAO.getProjectMembers(projectId);
            request.setAttribute("members", members);
            
            request.getRequestDispatcher("/WEB-INF/views/project/members.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }
    
    /**
     * Switches the active project.
     */
    private void switchProject(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        int projectId = Integer.parseInt(request.getParameter("projectId"));
        Project project = projectDAO.getProjectById(projectId);
        
        if (project == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has access to this project
        if (currentUser.getRole().equals("Admin") || projectMemberDAO.isUserMemberOfProject(projectId, currentUser.getUserId())) {
            // Set this project as the active project in session
            session.setAttribute("activeProject", project);
            
            // Redirect to dashboard or project view
            String referer = request.getHeader("Referer");
            if (referer != null) {
                response.sendRedirect(referer);
            } else {
                response.sendRedirect(request.getContextPath() + "/dashboard");
            }
        } else {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }
    
    /**
     * Creates a new project.
     */
    private void createProject(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Only Managers and Admins can create projects
        if (!currentUser.getRole().equals("Manager") && !currentUser.getRole().equals("Admin")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        
        if (name == null || name.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Project name is required");
            request.getRequestDispatcher("/WEB-INF/views/project/create.jsp").forward(request, response);
            return;
        }
        
        Project project = new Project(name, description);
        project = projectDAO.createProject(project);
        
        // Add the creator as a Project Manager
        ProjectMember member = new ProjectMember(project.getProjectId(), currentUser.getUserId(), "Project Manager");
        projectMemberDAO.addMemberToProject(member);
        
        response.sendRedirect(request.getContextPath() + "/projects/view/" + project.getProjectId());
    }
    
    /**
     * Updates an existing project.
     */
    private void updateProject(HttpServletRequest request, HttpServletResponse response, int projectId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        Project project = projectDAO.getProjectById(projectId);
        
        if (project == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to edit this project
        if (!currentUser.getRole().equals("Admin") && 
            !(projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId()) != null && 
              projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId()).equals("Project Manager"))) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        
        if (name == null || name.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Project name is required");
            request.setAttribute("project", project);
            request.getRequestDispatcher("/WEB-INF/views/project/edit.jsp").forward(request, response);
            return;
        }
        
        project.setName(name);
        project.setDescription(description);
        
        projectDAO.updateProject(project);
        
        response.sendRedirect(request.getContextPath() + "/projects/view/" + projectId);
    }
    
    /**
     * Deletes a project.
     */
    private void deleteProject(HttpServletRequest request, HttpServletResponse response, int projectId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Only Admins can delete projects
        if (!currentUser.getRole().equals("Admin")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        projectDAO.deleteProject(projectId);
        
        // Clear active project if it was the deleted one
        Project activeProject = (Project) session.getAttribute("activeProject");
        if (activeProject != null && activeProject.getProjectId() == projectId) {
            session.removeAttribute("activeProject");
        }
        
        response.sendRedirect(request.getContextPath() + "/projects");
    }
    
    /**
     * Adds a member to a project.
     */
    private void addMemberToProject(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        int projectId = Integer.parseInt(request.getParameter("projectId"));
        int userId = Integer.parseInt(request.getParameter("userId"));
        String projectRole = request.getParameter("projectRole");
        
        Project project = projectDAO.getProjectById(projectId);
        
        if (project == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to add members to this project
        if (!currentUser.getRole().equals("Admin") && 
            !(projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId()) != null && 
              projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId()).equals("Project Manager"))) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Check if user is already a member of the project
        if (projectMemberDAO.isUserMemberOfProject(projectId, userId)) {
            request.setAttribute("errorMessage", "User is already a member of this project");
            viewProjectMembers(request, response, projectId);
            return;
        }
        
        ProjectMember member = new ProjectMember(projectId, userId, projectRole);
        projectMemberDAO.addMemberToProject(member);
        
        // Create notification for the added user
        Notification notification = new Notification(
            userId, 
            "You have been added to project: " + project.getName(), 
            "Project"
        );
        notificationDAO.createNotification(notification);
        
        response.sendRedirect(request.getContextPath() + "/projects/members/" + projectId);
    }
    
    /**
     * Removes a member from a project.
     */
    private void removeMemberFromProject(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        int projectId = Integer.parseInt(request.getParameter("projectId"));
        int userId = Integer.parseInt(request.getParameter("userId"));
        
        Project project = projectDAO.getProjectById(projectId);
        
        if (project == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to remove members from this project
        if (!currentUser.getRole().equals("Admin") && 
            !(projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId()) != null && 
              projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId()).equals("Project Manager"))) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Can't remove yourself if you're the only Project Manager
        if (userId == currentUser.getUserId() && 
            projectMemberDAO.getUserProjectRole(projectId, userId).equals("Project Manager")) {
            
            // Count Project Managers
            int managerCount = 0;
            List<ProjectMember> members = projectMemberDAO.getProjectMembers(projectId);
            for (ProjectMember member : members) {
                if (member.getProjectRole().equals("Project Manager")) {
                    managerCount++;
                }
            }
            
            if (managerCount <= 1) {
                request.setAttribute("errorMessage", "Cannot remove yourself as you are the only Project Manager");
                viewProjectMembers(request, response, projectId);
                return;
            }
        }
        
        projectMemberDAO.removeMemberFromProject(projectId, userId);
        
        // Create notification for the removed user
        Notification notification = new Notification(
            userId, 
            "You have been removed from project: " + project.getName(), 
            "Project"
        );
        notificationDAO.createNotification(notification);
        
        response.sendRedirect(request.getContextPath() + "/projects/members/" + projectId);
    }
    
    /**
     * Updates a member's role in a project.
     */
    private void updateMemberRole(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        int memberId = Integer.parseInt(request.getParameter("memberId"));
        String projectRole = request.getParameter("projectRole");
        
        ProjectMember member = projectMemberDAO.getMemberById(memberId);
        
        if (member == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to update roles in this project
        if (!currentUser.getRole().equals("Admin") && 
            !(projectMemberDAO.getUserProjectRole(member.getProjectId(), currentUser.getUserId()) != null && 
              projectMemberDAO.getUserProjectRole(member.getProjectId(), currentUser.getUserId()).equals("Project Manager"))) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Can't downgrade yourself if you're the only Project Manager
        if (member.getUserId() == currentUser.getUserId() && 
            member.getProjectRole().equals("Project Manager") && 
            !projectRole.equals("Project Manager")) {
            
            // Count Project Managers
            int managerCount = 0;
            List<ProjectMember> members = projectMemberDAO.getProjectMembers(member.getProjectId());
            for (ProjectMember m : members) {
                if (m.getProjectRole().equals("Project Manager")) {
                    managerCount++;
                }
            }
            
            if (managerCount <= 1) {
                request.setAttribute("errorMessage", "Cannot change your role as you are the only Project Manager");
                viewProjectMembers(request, response, member.getProjectId());
                return;
            }
        }
        
        projectMemberDAO.updateMemberRole(memberId, projectRole);
        
        // Create notification for the user whose role was updated
        Project project = projectDAO.getProjectById(member.getProjectId());
        Notification notification = new Notification(
            member.getUserId(), 
            "Your role in project '" + project.getName() + "' has been updated to " + projectRole, 
            "Project"
        );
        notificationDAO.createNotification(notification);
        
        response.sendRedirect(request.getContextPath() + "/projects/members/" + member.getProjectId());
    }
    
    /**
     * Handles errors.
     */
    private void handleError(HttpServletRequest request, HttpServletResponse response, Exception e) 
            throws ServletException, IOException {
        e.printStackTrace();
        request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
        request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
    }
}