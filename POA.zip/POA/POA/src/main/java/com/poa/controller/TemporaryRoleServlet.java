package com.poa.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.poa.dao.TemporaryRoleDAO;
import com.poa.dao.ProjectDAO;
import com.poa.dao.UserDAO;
import com.poa.dao.NotificationDAO;
import com.poa.dao.ProjectMemberDAO;
import com.poa.model.TemporaryRole;
import com.poa.model.User;
import com.poa.model.Project;
import com.poa.model.Notification;

/**
 * Servlet for handling temporary role operations.
 */
@WebServlet("/temporaryRoles/*")
public class TemporaryRoleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private TemporaryRoleDAO temporaryRoleDAO = new TemporaryRoleDAO();
    private ProjectDAO projectDAO = new ProjectDAO();
    private UserDAO userDAO = new UserDAO();
    private NotificationDAO notificationDAO = new NotificationDAO();
    private ProjectMemberDAO projectMemberDAO = new ProjectMemberDAO();
    
    /**
     * Handles GET requests for temporary role operations.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // List temporary roles
                listTemporaryRoles(request, response);
            } else if (pathInfo.equals("/new")) {
                // Show create temporary role form
                showCreateForm(request, response);
            } else if (pathInfo.matches("/view/\\d+")) {
                // View temporary role details
                int roleId = Integer.parseInt(pathInfo.substring(6));
                viewTemporaryRole(request, response, roleId);
            } else if (pathInfo.matches("/edit/\\d+")) {
                // Show edit temporary role form
                int roleId = Integer.parseInt(pathInfo.substring(6));
                showEditForm(request, response, roleId);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            handleError(request, response, e);
        }
    }
    
    /**
     * Handles POST requests for temporary role operations.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // Create new temporary role
                createTemporaryRole(request, response);
            } else if (pathInfo.matches("/update/\\d+")) {
                // Update temporary role
                int roleId = Integer.parseInt(pathInfo.substring(8));
                updateTemporaryRole(request, response, roleId);
            } else if (pathInfo.matches("/delete/\\d+")) {
                // Delete temporary role
                int roleId = Integer.parseInt(pathInfo.substring(8));
                deleteTemporaryRole(request, response, roleId);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            handleError(request, response, e);
        } catch (ParseException e) {
            request.setAttribute("errorMessage", "Invalid date format: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
        }
    }
    
    /**
     * Lists all temporary roles.
     */
    private void listTemporaryRoles(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Get roles delegated by this user
        List<TemporaryRole> delegatedRoles = temporaryRoleDAO.getRolesDelegatedBy(currentUser.getUserId());
        request.setAttribute("delegatedRoles", delegatedRoles);
        
        // Get active roles assigned to this user
        List<TemporaryRole> assignedRoles = temporaryRoleDAO.getActiveTemporaryRoles(currentUser.getUserId());
        request.setAttribute("assignedRoles", assignedRoles);
        
        request.getRequestDispatcher("/WEB-INF/views/temporaryRole/list.jsp").forward(request, response);
    }
    
    /**
     * Shows the create temporary role form.
     */
    private void showCreateForm(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Only Managers can delegate roles
        if (!currentUser.getRole().equals("Manager") && !currentUser.getRole().equals("Admin")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Get projects where the user is a Project Manager
        List<Project> projects = projectDAO.getProjectsByUserId(currentUser.getUserId());
        request.setAttribute("projects", projects);
        
        request.getRequestDispatcher("/WEB-INF/views/temporaryRole/create.jsp").forward(request, response);
    }
    
    /**
     * Views temporary role details.
     */
    private void viewTemporaryRole(HttpServletRequest request, HttpServletResponse response, int roleId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        TemporaryRole role = temporaryRoleDAO.getTemporaryRoleById(roleId);
        
        if (role == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Check if user has permission to view this role
        if (currentUser.getRole().equals("Admin") || 
            role.getUserId() == currentUser.getUserId() || 
            role.getDelegatedBy() == currentUser.getUserId()) {
            
            request.setAttribute("role", role);
            request.getRequestDispatcher("/WEB-INF/views/temporaryRole/view.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }
    
    /**
     * Shows the edit temporary role form.
     */
    private void showEditForm(HttpServletRequest request, HttpServletResponse response, int roleId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        TemporaryRole role = temporaryRoleDAO.getTemporaryRoleById(roleId);
        
        if (role == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Only the delegator or an admin can edit the role
        if (currentUser.getRole().equals("Admin") || role.getDelegatedBy() == currentUser.getUserId()) {
            request.setAttribute("role", role);
            request.getRequestDispatcher("/WEB-INF/views/temporaryRole/edit.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }
    
    /**
     * Creates a new temporary role.
     */
    private void createTemporaryRole(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException, ParseException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Only Managers and Admins can delegate roles
        if (!currentUser.getRole().equals("Manager") && !currentUser.getRole().equals("Admin")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        int userId = Integer.parseInt(request.getParameter("userId"));
        String delegatedRole = request.getParameter("delegatedRole");
        int projectId = Integer.parseInt(request.getParameter("projectId"));
        
        // Parse dates
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        Date startDate = dateFormat.parse(request.getParameter("startDate"));
        Date endDate = dateFormat.parse(request.getParameter("endDate"));
        
        // Validate dates
        if (startDate.after(endDate)) {
            request.setAttribute("errorMessage", "Start date must be before end date");
            showCreateForm(request, response);
            return;
        }
        
        // Check if the current user has permission in this project
        if (!currentUser.getRole().equals("Admin")) {
            String userProjectRole = projectMemberDAO.getUserProjectRole(projectId, currentUser.getUserId());
            if (userProjectRole == null || !userProjectRole.equals("Project Manager")) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }
        }
        
        // Check if the target user is a member of the project
        if (!projectMemberDAO.isUserMemberOfProject(projectId, userId)) {
            request.setAttribute("errorMessage", "Selected user is not a member of this project");
            showCreateForm(request, response);
            return;
        }
        
        // Create temporary role
        TemporaryRole tempRole = new TemporaryRole(
            userId, delegatedRole, projectId, startDate, endDate, currentUser.getUserId()
        );
        
        temporaryRoleDAO.createTemporaryRole(tempRole);
        
        // Create notification for the user
        User targetUser = userDAO.getUserById(userId);
        Project project = projectDAO.getProjectById(projectId);
        
        Notification notification = new Notification(
            userId,
            "You have been assigned a temporary " + delegatedRole + " role in project '" + project.getName() + 
            "' from " + dateFormat.format(startDate) + " to " + dateFormat.format(endDate),
            "Role"
        );
        notificationDAO.createNotification(notification);
        
        response.sendRedirect(request.getContextPath() + "/temporaryRoles");
    }
    
    /**
     * Updates a temporary role.
     */
    private void updateTemporaryRole(HttpServletRequest request, HttpServletResponse response, int roleId) 
            throws SQLException, ServletException, IOException, ParseException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        TemporaryRole role = temporaryRoleDAO.getTemporaryRoleById(roleId);
        
        if (role == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Only the delegator or an admin can update the role
        if (!currentUser.getRole().equals("Admin") && role.getDelegatedBy() != currentUser.getUserId()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Parse new end date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        Date endDate = dateFormat.parse(request.getParameter("endDate"));
        
        // Validate date
        if (role.getStartDate().after(endDate)) {
            request.setAttribute("errorMessage", "End date must be after start date");
            showEditForm(request, response, roleId);
            return;
        }
        
        // Update role
        temporaryRoleDAO.updateEndDate(roleId, endDate);
        
        // Create notification for the user
        User targetUser = userDAO.getUserById(role.getUserId());
        Project project = projectDAO.getProjectById(role.getProjectId());
        
        Notification notification = new Notification(
            role.getUserId(),
            "Your temporary " + role.getDelegatedRole() + " role in project '" + project.getName() + 
            "' has been updated. New end date: " + dateFormat.format(endDate),
            "Role"
        );
        notificationDAO.createNotification(notification);
        
        response.sendRedirect(request.getContextPath() + "/temporaryRoles/view/" + roleId);
    }
    
    /**
     * Deletes a temporary role.
     */
    private void deleteTemporaryRole(HttpServletRequest request, HttpServletResponse response, int roleId) 
            throws SQLException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        TemporaryRole role = temporaryRoleDAO.getTemporaryRoleById(roleId);
        
        if (role == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Only the delegator or an admin can delete the role
        if (!currentUser.getRole().equals("Admin") && role.getDelegatedBy() != currentUser.getUserId()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        // Create notification for the user before deleting
        User targetUser = userDAO.getUserById(role.getUserId());
        Project project = projectDAO.getProjectById(role.getProjectId());
        
        Notification notification = new Notification(
            role.getUserId(),
            "Your temporary " + role.getDelegatedRole() + " role in project '" + project.getName() + "' has been revoked.",
            "Role"
        );
        notificationDAO.createNotification(notification);
        
        // Delete role
        temporaryRoleDAO.deleteTemporaryRole(roleId);
        
        response.sendRedirect(request.getContextPath() + "/temporaryRoles");
    }
    
    /**
     * Handles errors.
     */
    private void handleError(HttpServletRequest request, HttpServletResponse response, Exception e) 
            throws ServletException, IOException {
        e.printStackTrace();
        request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
        request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
    }
}