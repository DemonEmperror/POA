package com.poa.controller.filter;

import com.poa.model.User;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Filter to handle authentication and authorization
 */
public class AuthenticationFilter implements Filter {
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code, if needed
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);
        
        String loginURI = httpRequest.getContextPath() + "/login";
        boolean isLoginRequest = httpRequest.getRequestURI().equals(loginURI);
        boolean isLoginPage = httpRequest.getRequestURI().endsWith("login.jsp");
        boolean isResourceRequest = httpRequest.getRequestURI().contains("/css/") || 
                                   httpRequest.getRequestURI().contains("/js/") || 
                                   httpRequest.getRequestURI().contains("/images/");
        
        // Check if user is logged in or accessing a public resource
        boolean isLoggedIn = (session != null && session.getAttribute("user") != null);
        
        if (isLoggedIn || isLoginRequest || isLoginPage || isResourceRequest) {
            // User is authenticated or accessing login page or resources
            if (isLoggedIn) {
                // Check role-based access
                User user = (User) session.getAttribute("user");
                String requestURI = httpRequest.getRequestURI();
                
                // Role-based access control
                if (requestURI.contains("/admin/") && !user.getRole().equals(User.UserRole.Admin)) {
                    httpResponse.sendRedirect(httpRequest.getContextPath() + "/unauthorized.jsp");
                    return;
                } else if (requestURI.contains("/manager/") && 
                          !(user.getRole().equals(User.UserRole.Manager) || user.getRole().equals(User.UserRole.Admin))) {
                    httpResponse.sendRedirect(httpRequest.getContextPath() + "/unauthorized.jsp");
                    return;
                } else if (requestURI.contains("/teamlead/") && 
                          !(user.getRole().equals(User.UserRole.Team_Lead) || 
                            user.getRole().equals(User.UserRole.Manager) || 
                            user.getRole().equals(User.UserRole.Admin))) {
                    httpResponse.sendRedirect(httpRequest.getContextPath() + "/unauthorized.jsp");
                    return;
                }
            }
            
            // Continue the filter chain
            chain.doFilter(request, response);
        } else {
            // User is not logged in and trying to access a protected resource
            httpResponse.sendRedirect(loginURI);
        }
    }
    
    @Override
    public void destroy() {
        // Cleanup code, if needed
    }
}