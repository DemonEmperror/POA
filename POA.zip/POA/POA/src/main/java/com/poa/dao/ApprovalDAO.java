package com.poa.dao;

import com.poa.model.Approval;
import com.poa.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Approval-related database operations
 */
public class ApprovalDAO {
    
    /**
     * Get an approval by its ID
     * @param approvalId The approval's ID
     * @return Approval object if found, null otherwise
     */
    public Approval getApprovalById(int approvalId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Approval approval = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM approvals WHERE approval_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, approvalId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                approval = extractApprovalFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return approval;
    }
    
    /**
     * Create a new approval
     * @param approval The approval to create
     * @return The created approval with ID set, or null if creation failed
     */
    public Approval createApproval(Approval approval) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "INSERT INTO approvals (plan_id, approved_by, role, status, comments, timestamp) " +
                        "VALUES (?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, approval.getPlanId());
            stmt.setInt(2, approval.getApprovedBy());
            stmt.setString(3, approval.getRole().toString());
            stmt.setString(4, approval.getStatus().toString());
            stmt.setString(5, approval.getComments());
            stmt.setTimestamp(6, approval.getTimestamp());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                return null;
            }
            
            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                approval.setApprovalId(rs.getInt(1));
                return approval;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return null;
    }
    
    /**
     * Update an existing approval
     * @param approval The approval to update
     * @return true if update was successful, false otherwise
     */
    public boolean updateApproval(Approval approval) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "UPDATE approvals SET plan_id = ?, approved_by = ?, role = ?, " +
                        "status = ?, comments = ?, timestamp = ? WHERE approval_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, approval.getPlanId());
            stmt.setInt(2, approval.getApprovedBy());
            stmt.setString(3, approval.getRole().toString());
            stmt.setString(4, approval.getStatus().toString());
            stmt.setString(5, approval.getComments());
            stmt.setTimestamp(6, approval.getTimestamp());
            stmt.setInt(7, approval.getApprovalId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(null, stmt, conn);
        }
    }
    
    /**
     * Delete an approval by its ID
     * @param approvalId The ID of the approval to delete
     * @return true if deletion was successful, false otherwise
     */
    public boolean deleteApproval(int approvalId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "DELETE FROM approvals WHERE approval_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, approvalId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(null, stmt, conn);
        }
    }
    
    /**
     * Get all approvals for a specific plan
     * @param planId The plan's ID
     * @return List of approvals for the plan
     */
    public List<Approval> getApprovalsByPlanId(int planId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Approval> approvals = new ArrayList<>();
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM approvals WHERE plan_id = ? ORDER BY timestamp DESC";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, planId);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                approvals.add(extractApprovalFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return approvals;
    }
    
    /**
     * Get all approvals by a specific user
     * @param userId The user's ID
     * @return List of approvals by the user
     */
    public List<Approval> getApprovalsByUserId(int userId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Approval> approvals = new ArrayList<>();
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM approvals WHERE approved_by = ? ORDER BY timestamp DESC";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                approvals.add(extractApprovalFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return approvals;
    }
    
    /**
     * Get the most recent approval for a plan
     * @param planId The plan's ID
     * @return The most recent approval, or null if none exists
     */
    public Approval getLatestApprovalForPlan(int planId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Approval approval = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM approvals WHERE plan_id = ? ORDER BY timestamp DESC LIMIT 1";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, planId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                approval = extractApprovalFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return approval;
    }
    
    /**
     * Extract an Approval object from a ResultSet
     * @param rs The ResultSet to extract from
     * @return An Approval object
     * @throws SQLException if extraction fails
     */
    private Approval extractApprovalFromResultSet(ResultSet rs) throws SQLException {
        Approval approval = new Approval();
        approval.setApprovalId(rs.getInt("approval_id"));
        approval.setPlanId(rs.getInt("plan_id"));
        approval.setApprovedBy(rs.getInt("approved_by"));
        approval.setRole(Approval.ApproverRole.valueOf(rs.getString("role")));
        approval.setStatus(Approval.ApprovalStatus.valueOf(rs.getString("status")));
        approval.setComments(rs.getString("comments"));
        approval.setTimestamp(rs.getTimestamp("timestamp"));
        return approval;
    }
    
    /**
     * Close all database resources
     * @param rs ResultSet to close
     * @param stmt Statement to close
     * @param conn Connection to close
     */
    private void closeResources(ResultSet rs, PreparedStatement stmt, Connection conn) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}