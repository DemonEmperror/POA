package com.poa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.poa.model.Notification;
import com.poa.model.User;
import com.poa.util.DBUtil;

/**
 * Data Access Object for Notification-related database operations.
 */
public class NotificationDAO {
    
    private UserDAO userDAO = new UserDAO();
    
    /**
     * Creates a new notification.
     * 
     * @param notification The Notification object to be created
     * @return The created Notification with generated ID
     * @throws SQLException If a database error occurs
     */
    public Notification createNotification(Notification notification) throws SQLException {
        String sql = "INSERT INTO notifications (user_id, message, type, is_read) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, notification.getUserId());
            pstmt.setString(2, notification.getMessage());
            pstmt.setString(3, notification.getType());
            pstmt.setBoolean(4, notification.isRead());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating notification failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    notification.setNotificationId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating notification failed, no ID obtained.");
                }
            }
            
            return getNotificationById(notification.getNotificationId());
        }
    }
    
    /**
     * Creates notifications for multiple users with the same message.
     * 
     * @param userIds List of user IDs to notify
     * @param message The notification message
     * @param type The notification type
     * @throws SQLException If a database error occurs
     */
    public void createNotificationForMultipleUsers(List<Integer> userIds, String message, String type) throws SQLException {
        String sql = "INSERT INTO notifications (user_id, message, type, is_read) VALUES (?, ?, ?, false)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            conn.setAutoCommit(false);
            
            for (Integer userId : userIds) {
                pstmt.setInt(1, userId);
                pstmt.setString(2, message);
                pstmt.setString(3, type);
                pstmt.addBatch();
            }
            
            pstmt.executeBatch();
            conn.commit();
            
        } catch (SQLException e) {
            throw e;
        }
    }
    
    /**
     * Retrieves a notification by its ID.
     * 
     * @param notificationId The ID of the notification to retrieve
     * @return The Notification object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public Notification getNotificationById(int notificationId) throws SQLException {
        String sql = "SELECT * FROM notifications WHERE notification_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, notificationId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToNotification(rs);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Marks a notification as read.
     * 
     * @param notificationId The ID of the notification
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean markAsRead(int notificationId) throws SQLException {
        String sql = "UPDATE notifications SET is_read = true WHERE notification_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, notificationId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Marks all notifications for a user as read.
     * 
     * @param userId The ID of the user
     * @return Number of notifications marked as read
     * @throws SQLException If a database error occurs
     */
    public int markAllAsRead(int userId) throws SQLException {
        String sql = "UPDATE notifications SET is_read = true WHERE user_id = ? AND is_read = false";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            return pstmt.executeUpdate();
        }
    }
    
    /**
     * Deletes a notification.
     * 
     * @param notificationId The ID of the notification to delete
     * @return true if deletion was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean deleteNotification(int notificationId) throws SQLException {
        String sql = "DELETE FROM notifications WHERE notification_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, notificationId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Retrieves all notifications for a user.
     * 
     * @param userId The ID of the user
     * @param limit Maximum number of notifications to retrieve
     * @param onlyUnread Whether to retrieve only unread notifications
     * @return List of Notification objects
     * @throws SQLException If a database error occurs
     */
    public List<Notification> getUserNotifications(int userId, int limit, boolean onlyUnread) throws SQLException {
        String sql = "SELECT * FROM notifications WHERE user_id = ?";
        
        if (onlyUnread) {
            sql += " AND is_read = false";
        }
        
        sql += " ORDER BY created_at DESC";
        
        if (limit > 0) {
            sql += " LIMIT ?";
        }
        
        List<Notification> notifications = new ArrayList<>();
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            if (limit > 0) {
                pstmt.setInt(2, limit);
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    notifications.add(mapResultSetToNotification(rs));
                }
            }
        }
        
        return notifications;
    }
    
    /**
     * Counts unread notifications for a user.
     * 
     * @param userId The ID of the user
     * @return Number of unread notifications
     * @throws SQLException If a database error occurs
     */
    public int countUnreadNotifications(int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = false";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        
        return 0;
    }
    
    /**
     * Maps a ResultSet row to a Notification object.
     * 
     * @param rs The ResultSet containing notification data
     * @return A populated Notification object
     * @throws SQLException If a database error occurs
     */
    private Notification mapResultSetToNotification(ResultSet rs) throws SQLException {
        Notification notification = new Notification();
        notification.setNotificationId(rs.getInt("notification_id"));
        notification.setUserId(rs.getInt("user_id"));
        notification.setMessage(rs.getString("message"));
        notification.setType(rs.getString("type"));
        notification.setRead(rs.getBoolean("is_read"));
        notification.setCreatedAt(rs.getTimestamp("created_at"));
        
        try {
            // Load related user
            User user = userDAO.getUserById(notification.getUserId());
            notification.setUser(user);
        } catch (SQLException e) {
            // Just log the error but don't fail the whole operation
            System.err.println("Error loading related user for notification: " + e.getMessage());
        }
        
        return notification;
    }
}