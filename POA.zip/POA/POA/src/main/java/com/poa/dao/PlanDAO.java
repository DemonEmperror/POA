package com.poa.dao;

import com.poa.model.Plan;
import com.poa.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Plan-related database operations
 */
public class PlanDAO {
    
    /**
     * Get a plan by its ID
     * @param planId The plan's ID
     * @return Plan object if found, null otherwise
     */
    public Plan getPlanById(int planId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Plan plan = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plans WHERE plan_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, planId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                plan = extractPlanFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return plan;
    }
    
    /**
     * Create a new plan
     * @param plan The plan to create
     * @return The created plan with ID set, or null if creation failed
     */
    public Plan createPlan(Plan plan) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "INSERT INTO plans (user_id, date, status) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, plan.getUserId());
            stmt.setDate(2, plan.getDate());
            stmt.setString(3, plan.getStatus().toString());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                return null;
            }
            
            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                plan.setPlanId(rs.getInt(1));
                return plan;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return null;
    }
    
    /**
     * Update an existing plan
     * @param plan The plan to update
     * @return true if update was successful, false otherwise
     */
    public boolean updatePlan(Plan plan) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "UPDATE plans SET user_id = ?, date = ?, status = ? WHERE plan_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, plan.getUserId());
            stmt.setDate(2, plan.getDate());
            stmt.setString(3, plan.getStatus().toString());
            stmt.setInt(4, plan.getPlanId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(null, stmt, conn);
        }
    }
    
    /**
     * Delete a plan by its ID
     * @param planId The ID of the plan to delete
     * @return true if deletion was successful, false otherwise
     */
    public boolean deletePlan(int planId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "DELETE FROM plans WHERE plan_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, planId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(null, stmt, conn);
        }
    }
    
    /**
     * Get all plans for a specific user
     * @param userId The user's ID
     * @return List of plans for the user
     */
    public List<Plan> getPlansByUserId(int userId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Plan> plans = new ArrayList<>();
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plans WHERE user_id = ? ORDER BY date DESC";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                plans.add(extractPlanFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return plans;
    }
    
    /**
     * Get all plans for a specific date
     * @param date The date to filter by
     * @return List of plans for the date
     */
    public List<Plan> getPlansByDate(Date date) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Plan> plans = new ArrayList<>();
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plans WHERE date = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setDate(1, date);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                plans.add(extractPlanFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return plans;
    }
    
    /**
     * Get all plans with a specific status
     * @param status The status to filter by
     * @return List of plans with the specified status
     */
    public List<Plan> getPlansByStatus(Plan.PlanStatus status) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Plan> plans = new ArrayList<>();
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plans WHERE status = ? ORDER BY date DESC";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, status.toString());
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                plans.add(extractPlanFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return plans;
    }
    
    /**
     * Get all plans for a user with a specific status
     * @param userId The user's ID
     * @param status The status to filter by
     * @return List of plans matching both criteria
     */
    public List<Plan> getPlansByUserAndStatus(int userId, Plan.PlanStatus status) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Plan> plans = new ArrayList<>();
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plans WHERE user_id = ? AND status = ? ORDER BY date DESC";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setString(2, status.toString());
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                plans.add(extractPlanFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return plans;
    }
    
    /**
     * Get all plans for a specific user and date
     * @param userId The user's ID
     * @param date The date to filter by
     * @return List of plans matching both criteria
     */
    public List<Plan> getPlansByUserAndDate(int userId, Date date) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Plan> plans = new ArrayList<>();
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plans WHERE user_id = ? AND date = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setDate(2, date);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                plans.add(extractPlanFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return plans;
    }
    
    /**
     * Get the latest plan for a user
     * @param userId The user's ID
     * @return The most recent plan for the user, or null if none exists
     */
    public Plan getLatestPlanForUser(int userId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Plan plan = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plans WHERE user_id = ? ORDER BY date DESC LIMIT 1";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                plan = extractPlanFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return plan;
    }
    
    /**
     * Extract a Plan object from a ResultSet
     * @param rs The ResultSet to extract from
     * @return A Plan object
     * @throws SQLException if extraction fails
     */
    private Plan extractPlanFromResultSet(ResultSet rs) throws SQLException {
        Plan plan = new Plan();
        plan.setPlanId(rs.getInt("plan_id"));
        plan.setUserId(rs.getInt("user_id"));
        plan.setDate(rs.getDate("date"));
        plan.setStatus(Plan.PlanStatus.valueOf(rs.getString("status")));
        plan.setCreatedAt(rs.getTimestamp("created_at"));
        plan.setUpdatedAt(rs.getTimestamp("updated_at"));
        return plan;
    }
    
    /**
     * Close all database resources
     * @param rs ResultSet to close
     * @param stmt Statement to close
     * @param conn Connection to close
     */
    private void closeResources(ResultSet rs, PreparedStatement stmt, Connection conn) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}