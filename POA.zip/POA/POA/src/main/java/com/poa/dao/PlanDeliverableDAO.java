package com.poa.dao;

import com.poa.model.PlanDeliverable;
import com.poa.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for PlanDeliverable-related database operations
 */
public class PlanDeliverableDAO {
    
    /**
     * Get a deliverable by its ID
     * @param deliverableId The deliverable's ID
     * @return PlanDeliverable object if found, null otherwise
     */
    public PlanDeliverable getDeliverableById(int deliverableId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        PlanDeliverable deliverable = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plan_deliverables WHERE deliverable_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, deliverableId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                deliverable = extractDeliverableFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return deliverable;
    }
    
    /**
     * Create a new deliverable
     * @param deliverable The deliverable to create
     * @return The created deliverable with ID set, or null if creation failed
     */
    public PlanDeliverable createDeliverable(PlanDeliverable deliverable) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "INSERT INTO plan_deliverables (plan_id, description, estimated_time, " +
                        "actual_time, overflow_hours, rework, achieved) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, deliverable.getPlanId());
            stmt.setString(2, deliverable.getDescription());
            stmt.setBigDecimal(3, deliverable.getEstimatedTime());
            stmt.setBigDecimal(4, deliverable.getActualTime());
            stmt.setBigDecimal(5, deliverable.getOverflowHours());
            stmt.setString(6, deliverable.getRework().toString());
            stmt.setString(7, deliverable.getAchieved().toString());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                return null;
            }
            
            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                deliverable.setDeliverableId(rs.getInt(1));
                return deliverable;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return null;
    }
    
    /**
     * Update an existing deliverable
     * @param deliverable The deliverable to update
     * @return true if update was successful, false otherwise
     */
    public boolean updateDeliverable(PlanDeliverable deliverable) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "UPDATE plan_deliverables SET plan_id = ?, description = ?, estimated_time = ?, " +
                        "actual_time = ?, overflow_hours = ?, rework = ?, achieved = ? " +
                        "WHERE deliverable_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, deliverable.getPlanId());
            stmt.setString(2, deliverable.getDescription());
            stmt.setBigDecimal(3, deliverable.getEstimatedTime());
            stmt.setBigDecimal(4, deliverable.getActualTime());
            stmt.setBigDecimal(5, deliverable.getOverflowHours());
            stmt.setString(6, deliverable.getRework().toString());
            stmt.setString(7, deliverable.getAchieved().toString());
            stmt.setInt(8, deliverable.getDeliverableId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(null, stmt, conn);
        }
    }
    
    /**
     * Delete a deliverable by its ID
     * @param deliverableId The ID of the deliverable to delete
     * @return true if deletion was successful, false otherwise
     */
    public boolean deleteDeliverable(int deliverableId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DBUtil.getConnection();
            String sql = "DELETE FROM plan_deliverables WHERE deliverable_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, deliverableId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(null, stmt, conn);
        }
    }
    
    /**
     * Get all deliverables for a specific plan
     * @param planId The plan's ID
     * @return List of deliverables for the plan
     */
    public List<PlanDeliverable> getDeliverablesByPlanId(int planId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<PlanDeliverable> deliverables = new ArrayList<>();
        
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM plan_deliverables WHERE plan_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, planId);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                deliverables.add(extractDeliverableFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, stmt, conn);
        }
        
        return deliverables;
    }
    
    /**
     * Extract a PlanDeliverable object from a ResultSet
     * @param rs The ResultSet to extract from
     * @return A PlanDeliverable object
     * @throws SQLException if extraction fails
     */
    private PlanDeliverable extractDeliverableFromResultSet(ResultSet rs) throws SQLException {
        PlanDeliverable deliverable = new PlanDeliverable();
        deliverable.setDeliverableId(rs.getInt("deliverable_id"));
        deliverable.setPlanId(rs.getInt("plan_id"));
        deliverable.setDescription(rs.getString("description"));
        deliverable.setEstimatedTime(rs.getBigDecimal("estimated_time"));
        deliverable.setActualTime(rs.getBigDecimal("actual_time"));
        deliverable.setOverflowHours(rs.getBigDecimal("overflow_hours"));
        deliverable.setRework(PlanDeliverable.StatusEnum.valueOf(rs.getString("rework")));
        deliverable.setAchieved(PlanDeliverable.StatusEnum.valueOf(rs.getString("achieved")));
        return deliverable;
    }
    
    /**
     * Close all database resources
     * @param rs ResultSet to close
     * @param stmt Statement to close
     * @param conn Connection to close
     */
    private void closeResources(ResultSet rs, PreparedStatement stmt, Connection conn) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}