package com.poa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.poa.model.Project;
import com.poa.util.DBUtil;

/**
 * Data Access Object for Project-related database operations.
 */
public class ProjectDAO {
    
    /**
     * Creates a new project in the database.
     * 
     * @param project The Project object to be created
     * @return The created Project with generated ID
     * @throws SQLException If a database error occurs
     */
    public Project createProject(Project project) throws SQLException {
        String sql = "INSERT INTO projects (name, description) VALUES (?, ?)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, project.getName());
            pstmt.setString(2, project.getDescription());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating project failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    project.setProjectId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating project failed, no ID obtained.");
                }
            }
            
            return getProjectById(project.getProjectId());
        }
    }
    
    /**
     * Retrieves a project by its ID.
     * 
     * @param projectId The ID of the project to retrieve
     * @return The Project object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public Project getProjectById(int projectId) throws SQLException {
        String sql = "SELECT * FROM projects WHERE project_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, projectId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToProject(rs);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Updates an existing project in the database.
     * 
     * @param project The Project object to be updated
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean updateProject(Project project) throws SQLException {
        String sql = "UPDATE projects SET name = ?, description = ? WHERE project_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, project.getName());
            pstmt.setString(2, project.getDescription());
            pstmt.setInt(3, project.getProjectId());
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Deletes a project from the database.
     * 
     * @param projectId The ID of the project to delete
     * @return true if deletion was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean deleteProject(int projectId) throws SQLException {
        String sql = "DELETE FROM projects WHERE project_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, projectId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Retrieves all projects from the database.
     * 
     * @return List of all Project objects
     * @throws SQLException If a database error occurs
     */
    public List<Project> getAllProjects() throws SQLException {
        String sql = "SELECT * FROM projects ORDER BY name";
        List<Project> projects = new ArrayList<>();
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                projects.add(mapResultSetToProject(rs));
            }
        }
        
        return projects;
    }
    
    /**
     * Retrieves all projects that a user is a member of.
     * 
     * @param userId The ID of the user
     * @return List of Project objects the user is a member of
     * @throws SQLException If a database error occurs
     */
    public List<Project> getProjectsByUserId(int userId) throws SQLException {
        String sql = "SELECT p.* FROM projects p " +
                     "JOIN project_members pm ON p.project_id = pm.project_id " +
                     "WHERE pm.user_id = ? " +
                     "ORDER BY p.name";
        List<Project> projects = new ArrayList<>();
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    projects.add(mapResultSetToProject(rs));
                }
            }
        }
        
        return projects;
    }
    
    /**
     * Maps a ResultSet row to a Project object.
     * 
     * @param rs The ResultSet containing project data
     * @return A populated Project object
     * @throws SQLException If a database error occurs
     */
    private Project mapResultSetToProject(ResultSet rs) throws SQLException {
        Project project = new Project();
        project.setProjectId(rs.getInt("project_id"));
        project.setName(rs.getString("name"));
        project.setDescription(rs.getString("description"));
        project.setCreatedAt(rs.getTimestamp("created_at"));
        project.setUpdatedAt(rs.getTimestamp("updated_at"));
        return project;
    }
}