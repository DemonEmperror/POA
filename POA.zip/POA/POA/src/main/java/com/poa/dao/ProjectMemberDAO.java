package com.poa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.poa.model.ProjectMember;
import com.poa.model.User;
import com.poa.model.Project;
import com.poa.util.DBUtil;

/**
 * Data Access Object for ProjectMember-related database operations.
 */
public class ProjectMemberDAO {
    
    private UserDAO userDAO = new UserDAO();
    private ProjectDAO projectDAO = new ProjectDAO();
    
    /**
     * Adds a user to a project with a specific role.
     * 
     * @param projectMember The ProjectMember object to be created
     * @return The created ProjectMember with generated ID
     * @throws SQLException If a database error occurs
     */
    public ProjectMember addMemberToProject(ProjectMember projectMember) throws SQLException {
        String sql = "INSERT INTO project_members (project_id, user_id, project_role) VALUES (?, ?, ?)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, projectMember.getProjectId());
            pstmt.setInt(2, projectMember.getUserId());
            pstmt.setString(3, projectMember.getProjectRole());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Adding member to project failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    projectMember.setMemberId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Adding member to project failed, no ID obtained.");
                }
            }
            
            return getMemberById(projectMember.getMemberId());
        }
    }
    
    /**
     * Retrieves a project member by its ID.
     * 
     * @param memberId The ID of the project member to retrieve
     * @return The ProjectMember object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public ProjectMember getMemberById(int memberId) throws SQLException {
        String sql = "SELECT * FROM project_members WHERE member_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, memberId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToProjectMember(rs);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Updates a project member's role.
     * 
     * @param memberId The ID of the project member
     * @param projectRole The new project role
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean updateMemberRole(int memberId, String projectRole) throws SQLException {
        String sql = "UPDATE project_members SET project_role = ? WHERE member_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, projectRole);
            pstmt.setInt(2, memberId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Removes a user from a project.
     * 
     * @param projectId The ID of the project
     * @param userId The ID of the user
     * @return true if removal was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean removeMemberFromProject(int projectId, int userId) throws SQLException {
        String sql = "DELETE FROM project_members WHERE project_id = ? AND user_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, projectId);
            pstmt.setInt(2, userId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Retrieves all members of a project.
     * 
     * @param projectId The ID of the project
     * @return List of ProjectMember objects
     * @throws SQLException If a database error occurs
     */
    public List<ProjectMember> getProjectMembers(int projectId) throws SQLException {
        String sql = "SELECT * FROM project_members WHERE project_id = ?";
        List<ProjectMember> members = new ArrayList<>();
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, projectId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    members.add(mapResultSetToProjectMember(rs));
                }
            }
        }
        
        return members;
    }
    
    /**
     * Retrieves all projects a user is a member of.
     * 
     * @param userId The ID of the user
     * @return List of ProjectMember objects
     * @throws SQLException If a database error occurs
     */
    public List<ProjectMember> getUserMemberships(int userId) throws SQLException {
        String sql = "SELECT * FROM project_members WHERE user_id = ?";
        List<ProjectMember> memberships = new ArrayList<>();
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    memberships.add(mapResultSetToProjectMember(rs));
                }
            }
        }
        
        return memberships;
    }
    
    /**
     * Checks if a user is a member of a specific project.
     * 
     * @param projectId The ID of the project
     * @param userId The ID of the user
     * @return true if the user is a member, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean isUserMemberOfProject(int projectId, int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM project_members WHERE project_id = ? AND user_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, projectId);
            pstmt.setInt(2, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Gets a user's role in a specific project.
     * 
     * @param projectId The ID of the project
     * @param userId The ID of the user
     * @return The project role, or null if the user is not a member
     * @throws SQLException If a database error occurs
     */
    public String getUserProjectRole(int projectId, int userId) throws SQLException {
        String sql = "SELECT project_role FROM project_members WHERE project_id = ? AND user_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, projectId);
            pstmt.setInt(2, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("project_role");
                }
            }
        }
        
        return null;
    }
    
    /**
     * Maps a ResultSet row to a ProjectMember object.
     * 
     * @param rs The ResultSet containing project member data
     * @return A populated ProjectMember object
     * @throws SQLException If a database error occurs
     */
    private ProjectMember mapResultSetToProjectMember(ResultSet rs) throws SQLException {
        ProjectMember member = new ProjectMember();
        member.setMemberId(rs.getInt("member_id"));
        member.setProjectId(rs.getInt("project_id"));
        member.setUserId(rs.getInt("user_id"));
        member.setProjectRole(rs.getString("project_role"));
        member.setJoinedAt(rs.getTimestamp("joined_at"));
        
        try {
            // Load related objects
            User user = userDAO.getUserById(member.getUserId());
            Project project = projectDAO.getProjectById(member.getProjectId());
            
            member.setUser(user);
            member.setProject(project);
        } catch (SQLException e) {
            // Just log the error but don't fail the whole operation
            System.err.println("Error loading related objects for project member: " + e.getMessage());
        }
        
        return member;
    }
}