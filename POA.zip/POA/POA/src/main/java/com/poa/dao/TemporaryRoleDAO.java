package com.poa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.poa.model.TemporaryRole;
import com.poa.model.User;
import com.poa.model.Project;
import com.poa.util.DBUtil;

/**
 * Data Access Object for TemporaryRole-related database operations.
 */
public class TemporaryRoleDAO {
    
    private UserDAO userDAO = new UserDAO();
    private ProjectDAO projectDAO = new ProjectDAO();
    
    /**
     * Creates a new temporary role assignment.
     * 
     * @param tempRole The TemporaryRole object to be created
     * @return The created TemporaryRole with generated ID
     * @throws SQLException If a database error occurs
     */
    public TemporaryRole createTemporaryRole(TemporaryRole tempRole) throws SQLException {
        String sql = "INSERT INTO temporary_roles (user_id, delegated_role, project_id, start_date, end_date, delegated_by) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, tempRole.getUserId());
            pstmt.setString(2, tempRole.getDelegatedRole());
            pstmt.setInt(3, tempRole.getProjectId());
            pstmt.setTimestamp(4, new java.sql.Timestamp(tempRole.getStartDate().getTime()));
            pstmt.setTimestamp(5, new java.sql.Timestamp(tempRole.getEndDate().getTime()));
            pstmt.setInt(6, tempRole.getDelegatedBy());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating temporary role failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    tempRole.setRoleId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating temporary role failed, no ID obtained.");
                }
            }
            
            return getTemporaryRoleById(tempRole.getRoleId());
        }
    }
    
    /**
     * Retrieves a temporary role by its ID.
     * 
     * @param roleId The ID of the temporary role to retrieve
     * @return The TemporaryRole object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public TemporaryRole getTemporaryRoleById(int roleId) throws SQLException {
        String sql = "SELECT * FROM temporary_roles WHERE role_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, roleId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTemporaryRole(rs);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Updates the end date of a temporary role.
     * 
     * @param roleId The ID of the temporary role
     * @param endDate The new end date
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean updateEndDate(int roleId, Date endDate) throws SQLException {
        String sql = "UPDATE temporary_roles SET end_date = ? WHERE role_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setTimestamp(1, new java.sql.Timestamp(endDate.getTime()));
            pstmt.setInt(2, roleId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Deletes a temporary role.
     * 
     * @param roleId The ID of the temporary role to delete
     * @return true if deletion was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean deleteTemporaryRole(int roleId) throws SQLException {
        String sql = "DELETE FROM temporary_roles WHERE role_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, roleId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Retrieves all active temporary roles for a user.
     * 
     * @param userId The ID of the user
     * @return List of active TemporaryRole objects
     * @throws SQLException If a database error occurs
     */
    public List<TemporaryRole> getActiveTemporaryRoles(int userId) throws SQLException {
        String sql = "SELECT * FROM temporary_roles " +
                     "WHERE user_id = ? AND start_date <= NOW() AND end_date >= NOW()";
        List<TemporaryRole> roles = new ArrayList<>();
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    roles.add(mapResultSetToTemporaryRole(rs));
                }
            }
        }
        
        return roles;
    }
    
    /**
     * Retrieves all active temporary roles for a user in a specific project.
     * 
     * @param userId The ID of the user
     * @param projectId The ID of the project
     * @return List of active TemporaryRole objects
     * @throws SQLException If a database error occurs
     */
    public List<TemporaryRole> getActiveTemporaryRoles(int userId, int projectId) throws SQLException {
        String sql = "SELECT * FROM temporary_roles " +
                     "WHERE user_id = ? AND project_id = ? AND start_date <= NOW() AND end_date >= NOW()";
        List<TemporaryRole> roles = new ArrayList<>();
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.setInt(2, projectId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    roles.add(mapResultSetToTemporaryRole(rs));
                }
            }
        }
        
        return roles;
    }
    
    /**
     * Checks if a user has an active temporary manager role in a project.
     * 
     * @param userId The ID of the user
     * @param projectId The ID of the project
     * @return true if the user has an active temporary manager role, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean hasActiveTemporaryManagerRole(int userId, int projectId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM temporary_roles " +
                     "WHERE user_id = ? AND project_id = ? AND delegated_role = 'Manager' " +
                     "AND start_date <= NOW() AND end_date >= NOW()";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.setInt(2, projectId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Retrieves all temporary roles delegated by a specific user.
     * 
     * @param delegatedBy The ID of the user who delegated the roles
     * @return List of TemporaryRole objects
     * @throws SQLException If a database error occurs
     */
    public List<TemporaryRole> getRolesDelegatedBy(int delegatedBy) throws SQLException {
        String sql = "SELECT * FROM temporary_roles WHERE delegated_by = ? ORDER BY end_date DESC";
        List<TemporaryRole> roles = new ArrayList<>();
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, delegatedBy);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    roles.add(mapResultSetToTemporaryRole(rs));
                }
            }
        }
        
        return roles;
    }
    
    /**
     * Maps a ResultSet row to a TemporaryRole object.
     * 
     * @param rs The ResultSet containing temporary role data
     * @return A populated TemporaryRole object
     * @throws SQLException If a database error occurs
     */
    private TemporaryRole mapResultSetToTemporaryRole(ResultSet rs) throws SQLException {
        TemporaryRole role = new TemporaryRole();
        role.setRoleId(rs.getInt("role_id"));
        role.setUserId(rs.getInt("user_id"));
        role.setDelegatedRole(rs.getString("delegated_role"));
        role.setProjectId(rs.getInt("project_id"));
        role.setStartDate(rs.getTimestamp("start_date"));
        role.setEndDate(rs.getTimestamp("end_date"));
        role.setDelegatedBy(rs.getInt("delegated_by"));
        role.setCreatedAt(rs.getTimestamp("created_at"));
        
        try {
            // Load related objects
            User user = userDAO.getUserById(role.getUserId());
            User delegator = userDAO.getUserById(role.getDelegatedBy());
            Project project = projectDAO.getProjectById(role.getProjectId());
            
            role.setUser(user);
            role.setDelegator(delegator);
            role.setProject(project);
        } catch (SQLException e) {
            // Just log the error but don't fail the whole operation
            System.err.println("Error loading related objects for temporary role: " + e.getMessage());
        }
        
        return role;
    }
}