package com.poa.model;

import java.sql.Timestamp;

/**
 * Approval model representing entries in the approvals table
 */
public class Approval {
    private int approvalId;
    private int planId;
    private int approvedBy;
    private ApproverRole role;
    private ApprovalStatus status;
    private String comments;
    private Timestamp timestamp;
    
    // Enum for approver role
    public enum ApproverRole {
        Team_Lead,
        Manager
    }
    
    // Enum for approval status
    public enum ApprovalStatus {
        Approved,
        Rejected,
        Needs_Rework
    }
    
    // Constructors
    public Approval() {
    }
    
    public Approval(int approvalId, int planId, int approvedBy, ApproverRole role, 
                   ApprovalStatus status, String comments, Timestamp timestamp) {
        this.approvalId = approvalId;
        this.planId = planId;
        this.approvedBy = approvedBy;
        this.role = role;
        this.status = status;
        this.comments = comments;
        this.timestamp = timestamp;
    }
    
    // Getters and Setters
    public int getApprovalId() {
        return approvalId;
    }
    
    public void setApprovalId(int approvalId) {
        this.approvalId = approvalId;
    }
    
    public int getPlanId() {
        return planId;
    }
    
    public void setPlanId(int planId) {
        this.planId = planId;
    }
    
    public int getApprovedBy() {
        return approvedBy;
    }
    
    public void setApprovedBy(int approvedBy) {
        this.approvedBy = approvedBy;
    }
    
    public ApproverRole getRole() {
        return role;
    }
    
    public void setRole(ApproverRole role) {
        this.role = role;
    }
    
    public ApprovalStatus getStatus() {
        return status;
    }
    
    public void setStatus(ApprovalStatus status) {
        this.status = status;
    }
    
    public String getComments() {
        return comments;
    }
    
    public void setComments(String comments) {
        this.comments = comments;
    }
    
    public Timestamp getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
    @Override
    public String toString() {
        return "Approval{" +
                "approvalId=" + approvalId +
                ", planId=" + planId +
                ", approvedBy=" + approvedBy +
                ", role=" + role +
                ", status=" + status +
                ", comments='" + comments + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}