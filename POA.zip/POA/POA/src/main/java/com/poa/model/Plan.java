package com.poa.model;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * Plan model representing entries in the plans table
 */
public class Plan {
    private int planId;
    private int userId;
    private Date date;
    private PlanStatus status;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    
    // Enum for plan status
    public enum PlanStatus {
        Pending,
        Approved,
        Rejected,
        Needs_Rework
    }
    
    // Constructors
    public Plan() {
    }
    
    public Plan(int planId, int userId, Date date, PlanStatus status, Timestamp createdAt, Timestamp updatedAt) {
        this.planId = planId;
        this.userId = userId;
        this.date = date;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    // Getters and Setters
    public int getPlanId() {
        return planId;
    }
    
    public void setPlanId(int planId) {
        this.planId = planId;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public Date getDate() {
        return date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
    
    public PlanStatus getStatus() {
        return status;
    }
    
    public void setStatus(PlanStatus status) {
        this.status = status;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    @Override
    public String toString() {
        return "Plan{" +
                "planId=" + planId +
                ", userId=" + userId +
                ", date=" + date +
                ", status=" + status +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
}