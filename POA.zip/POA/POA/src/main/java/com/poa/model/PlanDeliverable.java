package com.poa.model;

import java.math.BigDecimal;

/**
 * PlanDeliverable model representing entries in the plan_deliverables table
 */
public class PlanDeliverable {
    private int deliverableId;
    private int planId;
    private String description;
    private BigDecimal estimatedTime;
    private BigDecimal actualTime;
    private BigDecimal overflowHours;
    private StatusEnum rework;
    private StatusEnum achieved;
    
    // Enum for rework and achieved status
    public enum StatusEnum {
        Yes,
        No,
        None
    }
    
    // Constructors
    public PlanDeliverable() {
    }
    
    public PlanDeliverable(int deliverableId, int planId, String description, BigDecimal estimatedTime, 
                          BigDecimal actualTime, BigDecimal overflowHours, StatusEnum rework, StatusEnum achieved) {
        this.deliverableId = deliverableId;
        this.planId = planId;
        this.description = description;
        this.estimatedTime = estimatedTime;
        this.actualTime = actualTime;
        this.overflowHours = overflowHours;
        this.rework = rework;
        this.achieved = achieved;
    }
    
    // Getters and Setters
    public int getDeliverableId() {
        return deliverableId;
    }
    
    public void setDeliverableId(int deliverableId) {
        this.deliverableId = deliverableId;
    }
    
    public int getPlanId() {
        return planId;
    }
    
    public void setPlanId(int planId) {
        this.planId = planId;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public BigDecimal getEstimatedTime() {
        return estimatedTime;
    }
    
    public void setEstimatedTime(BigDecimal estimatedTime) {
        this.estimatedTime = estimatedTime;
    }
    
    public BigDecimal getActualTime() {
        return actualTime;
    }
    
    public void setActualTime(BigDecimal actualTime) {
        this.actualTime = actualTime;
    }
    
    public BigDecimal getOverflowHours() {
        return overflowHours;
    }
    
    public void setOverflowHours(BigDecimal overflowHours) {
        this.overflowHours = overflowHours;
    }
    
    public StatusEnum getRework() {
        return rework;
    }
    
    public void setRework(StatusEnum rework) {
        this.rework = rework;
    }
    
    public StatusEnum getAchieved() {
        return achieved;
    }
    
    public void setAchieved(StatusEnum achieved) {
        this.achieved = achieved;
    }
    
    /**
     * Calculate the difference between estimated and actual time
     * @return the difference as a BigDecimal
     */
    public BigDecimal getTimeDifference() {
        if (actualTime == null) {
            return null;
        }
        return actualTime.subtract(estimatedTime);
    }
    
    @Override
    public String toString() {
        return "PlanDeliverable{" +
                "deliverableId=" + deliverableId +
                ", planId=" + planId +
                ", description='" + description + '\'' +
                ", estimatedTime=" + estimatedTime +
                ", actualTime=" + actualTime +
                ", overflowHours=" + overflowHours +
                ", rework=" + rework +
                ", achieved=" + achieved +
                '}';
    }
}