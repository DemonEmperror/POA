package com.poa.model;

import java.sql.Timestamp;

/**
 * Model class representing a project member in the POA system.
 * Links users to projects with specific roles.
 */
public class ProjectMember {
    private int memberId;
    private int projectId;
    private int userId;
    private String projectRole; // "Project Manager", "Team Lead", "Team Member"
    private Timestamp joinedAt;
    
    // Reference objects
    private User user;
    private Project project;
    
    // Default constructor
    public ProjectMember() {
    }
    
    // Constructor with essential fields
    public ProjectMember(int projectId, int userId, String projectRole) {
        this.projectId = projectId;
        this.userId = userId;
        this.projectRole = projectRole;
    }
    
    // Full constructor
    public ProjectMember(int memberId, int projectId, int userId, String projectRole, Timestamp joinedAt) {
        this.memberId = memberId;
        this.projectId = projectId;
        this.userId = userId;
        this.projectRole = projectRole;
        this.joinedAt = joinedAt;
    }
    
    // Getters and Setters
    public int getMemberId() {
        return memberId;
    }
    
    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }
    
    public int getProjectId() {
        return projectId;
    }
    
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public String getProjectRole() {
        return projectRole;
    }
    
    public void setProjectRole(String projectRole) {
        this.projectRole = projectRole;
    }
    
    public Timestamp getJoinedAt() {
        return joinedAt;
    }
    
    public void setJoinedAt(Timestamp joinedAt) {
        this.joinedAt = joinedAt;
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public Project getProject() {
        return project;
    }
    
    public void setProject(Project project) {
        this.project = project;
    }
    
    @Override
    public String toString() {
        return "ProjectMember [memberId=" + memberId + ", projectId=" + projectId + ", userId=" + userId 
                + ", projectRole=" + projectRole + ", joinedAt=" + joinedAt + "]";
    }
}