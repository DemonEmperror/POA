package com.poa.model;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Model class representing a temporary role assignment in the POA system.
 * Used for role delegation (e.g., temporary manager).
 */
public class TemporaryRole {
    private int roleId;
    private int userId;
    private String delegatedRole; // "Manager", "Team Lead"
    private int projectId;
    private Date startDate;
    private Date endDate;
    private int delegatedBy;
    private Timestamp createdAt;
    
    // Reference objects
    private User user;
    private User delegator;
    private Project project;
    
    // Default constructor
    public TemporaryRole() {
    }
    
    // Constructor with essential fields
    public TemporaryRole(int userId, String delegatedRole, int projectId, Date startDate, Date endDate, int delegatedBy) {
        this.userId = userId;
        this.delegatedRole = delegatedRole;
        this.projectId = projectId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.delegatedBy = delegatedBy;
    }
    
    // Full constructor
    public TemporaryRole(int roleId, int userId, String delegatedRole, int projectId, 
                         Date startDate, Date endDate, int delegatedBy, Timestamp createdAt) {
        this.roleId = roleId;
        this.userId = userId;
        this.delegatedRole = delegatedRole;
        this.projectId = projectId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.delegatedBy = delegatedBy;
        this.createdAt = createdAt;
    }
    
    /**
     * Checks if this temporary role is currently active.
     * @return true if the current date is between start and end dates
     */
    public boolean isActive() {
        Date now = new Date();
        return now.after(startDate) && now.before(endDate);
    }
    
    // Getters and Setters
    public int getRoleId() {
        return roleId;
    }
    
    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public String getDelegatedRole() {
        return delegatedRole;
    }
    
    public void setDelegatedRole(String delegatedRole) {
        this.delegatedRole = delegatedRole;
    }
    
    public int getProjectId() {
        return projectId;
    }
    
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    
    public Date getStartDate() {
        return startDate;
    }
    
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    
    public Date getEndDate() {
        return endDate;
    }
    
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    
    public int getDelegatedBy() {
        return delegatedBy;
    }
    
    public void setDelegatedBy(int delegatedBy) {
        this.delegatedBy = delegatedBy;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public User getDelegator() {
        return delegator;
    }
    
    public void setDelegator(User delegator) {
        this.delegator = delegator;
    }
    
    public Project getProject() {
        return project;
    }
    
    public void setProject(Project project) {
        this.project = project;
    }
    
    @Override
    public String toString() {
        return "TemporaryRole [roleId=" + roleId + ", userId=" + userId + ", delegatedRole=" + delegatedRole 
                + ", projectId=" + projectId + ", startDate=" + startDate + ", endDate=" + endDate 
                + ", delegatedBy=" + delegatedBy + ", createdAt=" + createdAt + "]";
    }
}