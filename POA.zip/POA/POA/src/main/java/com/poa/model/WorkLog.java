package com.poa.model;

import java.math.BigDecimal;
import java.sql.Date;

/**
 * WorkLog model representing entries in the work_logs table
 */
public class WorkLog {
    private int logId;
    private int userId;
    private Date date;
    private int planId;
    private BigDecimal actualTime;
    private String unplannedWork;
    
    // Constructors
    public WorkLog() {
    }
    
    public WorkLog(int logId, int userId, Date date, int planId, BigDecimal actualTime, String unplannedWork) {
        this.logId = logId;
        this.userId = userId;
        this.date = date;
        this.planId = planId;
        this.actualTime = actualTime;
        this.unplannedWork = unplannedWork;
    }
    
    // Getters and Setters
    public int getLogId() {
        return logId;
    }
    
    public void setLogId(int logId) {
        this.logId = logId;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public Date getDate() {
        return date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
    
    public int getPlanId() {
        return planId;
    }
    
    public void setPlanId(int planId) {
        this.planId = planId;
    }
    
    public BigDecimal getActualTime() {
        return actualTime;
    }
    
    public void setActualTime(BigDecimal actualTime) {
        this.actualTime = actualTime;
    }
    
    public String getUnplannedWork() {
        return unplannedWork;
    }
    
    public void setUnplannedWork(String unplannedWork) {
        this.unplannedWork = unplannedWork;
    }
    
    @Override
    public String toString() {
        return "WorkLog{" +
                "logId=" + logId +
                ", userId=" + userId +
                ", date=" + date +
                ", planId=" + planId +
                ", actualTime=" + actualTime +
                ", unplannedWork='" + unplannedWork + '\'' +
                '}';
    }
}