package com.poa.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Utility class for password hashing and validation
 * Note: In a production environment, use a dedicated library like BCrypt
 */
public class PasswordUtil {
    
    /**
     * Generate a salt for password hashing
     * @return A random salt as a byte array
     */
    public static byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return salt;
    }
    
    /**
     * Hash a password with SHA-256 and a salt
     * @param password The password to hash
     * @param salt The salt to use
     * @return The hashed password
     */
    public static String hashPassword(String password, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedPassword = md.digest(password.getBytes());
            
            // Convert to hex string
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedPassword) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Hash a password with SHA-256 and a generated salt
     * @param password The password to hash
     * @return The hashed password with salt, formatted as "hash:salt"
     */
    public static String hashPassword(String password) {
        byte[] salt = generateSalt();
        String hashedPassword = hashPassword(password, salt);
        
        // Convert salt to hex string
        StringBuilder sb = new StringBuilder();
        for (byte b : salt) {
            sb.append(String.format("%02x", b));
        }
        String saltHex = sb.toString();
        
        // Return in format "hash:salt"
        return hashedPassword + ":" + saltHex;
    }
    
    /**
     * Verify a password against a stored hash
     * @param password The password to verify
     * @param storedHash The stored hash in format "hash:salt"
     * @return true if the password matches, false otherwise
     */
    public static boolean verifyPassword(String password, String storedHash) {
        String[] parts = storedHash.split(":");
        if (parts.length != 2) {
            return false;
        }
        
        String hash = parts[0];
        String saltHex = parts[1];
        
        // Convert salt from hex string to byte array
        byte[] salt = new byte[saltHex.length() / 2];
        for (int i = 0; i < salt.length; i++) {
            int index = i * 2;
            salt[i] = (byte) Integer.parseInt(saltHex.substring(index, index + 2), 16);
        }
        
        // Hash the input password with the retrieved salt
        String hashedPassword = hashPassword(password, salt);
        
        // Compare with the stored hash
        return hashedPassword.equals(hash);
    }
}