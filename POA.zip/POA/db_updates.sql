-- Projects Table
CREATE TABLE projects (
    project_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Project Members Table - Links users to projects with specific roles
CREATE TABLE project_members (
    member_id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    project_role ENUM('Project Manager', 'Team Lead', 'Team Member') NOT NULL,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(project_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    UNIQUE KEY unique_project_user (project_id, user_id)
);

-- Temporary Roles Table - For role delegation
CREATE TABLE temporary_roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    delegated_role ENUM('Manager', 'Team Lead') NOT NULL,
    project_id INT NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    delegated_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (project_id) REFERENCES projects(project_id),
    FOREIGN KEY (delegated_by) REFERENCES users(user_id)
);

-- Notifications Table
CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    type ENUM('Plan', 'Approval', 'Role', 'Project') NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Update Plans Table to include project_id
ALTER TABLE plans ADD COLUMN project_id INT NOT NULL AFTER user_id;
ALTER TABLE plans ADD FOREIGN KEY (project_id) REFERENCES projects(project_id);

-- Indexes for Performance
CREATE INDEX idx_project_members ON project_members(project_id, user_id);
CREATE INDEX idx_temporary_roles ON temporary_roles(user_id, project_id, end_date);
CREATE INDEX idx_plans_project ON plans(project_id, status);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);

-- Sample Data for Testing
INSERT INTO projects (name, description) VALUES 
('Web Application Redesign', 'Complete redesign of the company website'),
('Mobile App Development', 'New mobile application for customer engagement'),
('Database Migration', 'Migration from legacy database to new platform');

-- Add project_id to existing plans (assuming default project 1)
UPDATE plans SET project_id = 1;